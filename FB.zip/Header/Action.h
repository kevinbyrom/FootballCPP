/*#ifndef __ACTION_H
#define __ACTION_H


#define ACT_STAND
#define ACT_FACE
#define ACT_WALK
#define ACT_RUN
#define ACT_HANDOFF
#define ACT_FAKEHANDOFF


#define DEST_COORDINATE		0
#define DEST_FRAME			1


struct ACTION
	{
	int Type;
	int DestType;

	int DestX;
	int DestY;
	int DestFrame;
	};



#endif*/