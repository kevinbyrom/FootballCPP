#ifndef __STRTOOLS_H
#define __STRTOOLS_H


void RTrim(char * string, int slen);


#endif