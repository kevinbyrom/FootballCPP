#ifndef __PLAYEROBJ_H
#define __PLAYEROBJ_H


#include "Gamelib.h"
#include "PlayerInfo.h"
#include "Constants.h"


///////////////
// Constants //
///////////////


const float PLAYER_WIDTH			= 10.0f;
const float PLAYER_HEIGHT			= 32.0f;

const int ACTION_END					= -1;
const int ACTION_STAND					= 0;
const int ACTION_STANCE					= 1;
const int ACTION_RUN					= 2;
const int ACTION_RUN_TOSS				= 3;
const int ACTION_RUNTO					= 4;
const int ACTION_RUNTO_ABSOLUTE			= 5;
const int ACTION_RUNTO_BALL_HOLDER		= 6;
const int ACTION_FACE					= 7;
const int ACTION_BLOCK					= 8;

const int ACTION_HANDOFF				= 20;
const int ACTION_FAKE_HANDOFF			= 21;
const int ACTION_TOSS					= 22;
const int ACTION_FAKE_TOSS				= 23;
const int ACTION_GET_HANDOFF			= 24;
const int ACTION_GET_FAKE_HANDOFF		= 25;

const int ACTION_SPIKE					= 40;
const int ACTION_KNEEL					= 41;

const int ACTION_SNAP					= 60;
const int ACTION_PLACEHOLD				= 61;
const int ACTION_KICK					= 62;
const int ACTION_PUNT					= 63;
const int ACTION_START_POWER			= 64;
const int ACTION_END_POWER				= 65;
const int ACTION_START_AIM				= 66;
const int ACTION_END_AIM				= 67;

const int ACTION_WAIT_FOR_SNAP_QB		= 80; 
const int ACTION_WAIT_FOR_SNAP_P		= 81;
const int ACTION_WAIT_FOR_SNAP_PH		= 82;

const int ACTION_CATCH_PUNT				= 100;
const int ACTION_CATCH_BALL				= 101;
const int ACTION_BLOCK_FOR_BALL_HOLDER	= 102;
const int ACTION_TACKLE_BALL_HOLDER		= 103;
const int ACTION_RECOVER_FUMBLE			= 104;

const int ACTION_TARGET_PASSER			= 120;
const int ACTION_TARGET_RUSHER			= 121;
const int ACTION_TARGET_KICKER			= 122;
const int ACTION_TARGET_PUNTER			= 123;
const int ACTION_TARGET_PLACEHOLDER		= 124;

const int ACTION_FIND_RECEIVER			= 200;
const int ACTION_FIND_CLOSEST_RECEIVER	= 201;
const int ACTION_LINEUP_TO_RECEIVER		= 202;
const int ACTION_WAIT_FOR_RECEIVER		= 203;
const int ACTION_WAIT_FOR_ANY_RECEIVER	= 204;
const int ACTION_SAFETY_WAIT_HIGH		= 205;
const int ACTION_SAFETY_WAIT_LOW		= 206;
const int ACTION_COVER_RECEIVER			= 207;

const int ACTION_HIDE_BALL_HOLDER		= 300;
const int ACTION_REVEAL_BALL_HOLDER		= 301;

const int ACTION_USER_CONTROL			= 320;
const int ACTION_DELAY					= 321;



const int FRAME_STAND			= 0;
const int FRAME_RUN				= 1;
const int FRAME_LEAP			= 10;
const int FRAME_DIVE			= 7;
const int FRAME_GRAPPLE			= 11;
const int FRAME_LAY				= 13;
const int FRAME_SIT				= 14;
const int FRAME_GETUP			= 16;
const int FRAME_STANCE			= 18;
const int FRAME_THROW			= 19;
const int FRAME_HANDOFF			= 22;

const int FRAME_AMT_STAND		= 1;
const int FRAME_AMT_RUN			= 4;
const int FRAME_AMT_LEAP		= 1;
const int FRAME_AMT_DIVE		= 1;
const int FRAME_AMT_GRAPPLE		= 2;
const int FRAME_AMT_LAY			= 1;
const int FRAME_AMT_SIT			= 2;
const int FRAME_AMT_GETUP		= 2;
const int FRAME_AMT_STANCE		= 1;
const int FRAME_AMT_THROW		= 3;
const int FRAME_AMT_HANDOFF		= 2;

const float STAND_DAMAGE	= -0.01f;
const float RUN_DAMAGE		= 0.001f;
const float GRAPPLE_DAMAGE	= 0.05f;



struct PLAYER_OBJ_FLAGS
	{
	BOOL Passer;
	BOOL Receiver;
	BOOL IsDefReceiver;
	BOOL Blocker;
	BOOL Rusher;
	BOOL Kicker;
	BOOL Punter;
	BOOL Placeholder;
	BOOL IsDefBallHolder;
	};




///////////////////
// Player Object //
///////////////////


class PLAYER_OBJ : public OBJECT
	{
	public:
		
		PLAYER_OBJ();


		enum {	STATE_STAND			= 0,
				STATE_STANCE,
				STATE_RUN,
				STATE_SLOWDOWN,
				STATE_LEAP,
				STATE_DIVE,
				STATE_GRAPPLE,
				STATE_BREAKGRAPPLE,
				STATE_TUMBLE,
				STATE_LAYDOWN,
				STATE_SIT,
				STATE_GETUP,
				STATE_HANDOFF,
				STATE_FAKEHANDOFF,
				STATE_TOSS,
				STATE_SNAP,
				STATE_THROW,
				STATE_KICK,
				STATE_AIMKICK,
				STATE_PUNT,
				STATE_PLACEHOLD,
				STATE_CELEBRATE,
				STATE_COMPLAIN
			};


		virtual void SetSide(){}

		void PrepareForPlay();

		virtual void Update();

	
	public:

		void SetPlayerInfo(PLAYER_INFO * pi);

		PLAYER_INFO * PlayerInfo;

		int SideNum;
		int TeamNum;
		
		int ControlType;

		int FaceDir;
		
		int Speed;
		
		int ThrowType;
		float ThrowAcc;
		float ThrowPow;
		float ThrowCtr;
		
		COORDINATE_F	KickDir;
		float			KickPow;


		BOOL Catching;
		BOOL HasBall;

		PLAYER_OBJ_FLAGS Flag;


	protected:

		void ProcessControl();
		virtual void ProcessState(int reason);
		void DoControl_Action();


	protected:

		virtual DWORD OnMessage(int from, int msg, DWORD data1, DWORD data2);

		void OnBallHiked();
		void OnHandOffGiven();
		void OnFakeHandOffGiven();
		void OnBallThrown(int time);
		void OnBallReceived(PLAYER_OBJ * target);
		void OnBallFumbled();
		void OnBallPassedScrimmage(PLAYER_OBJ * target);
		void OnPlayDead();
		void OnTouchdown(PLAYER_OBJ * target);
		DWORD OnGrappled(PLAYER_OBJ * target);
		void OnGrappleBroken(PLAYER_OBJ * target);
		void OnTackled(PLAYER_OBJ * target);
		void OnTakenDown();


	public:

		void Stop();
		void SlowStop();
		void UpdateDeltas();

		BOOL IsStanding();
		BOOL IsFacing(float xdir, float ydir);
		void FaceMoveDirection();

		int GetDirection(float xdir, float ydir);


	public:

		void Face(float xdir, float ydir);
		void Stand();
		void Stance();
		void Run(float xdir, float ydir);
		void Leap(float xdir, float ydir);
		void Dive(float xdir, float ydir);
		void Grapple(float xdir, float ydir);
		void BreakGrapple(float xdir, float ydir);
		void Tumble(float xdir, float ydir);
		void LayDown();
		void Sit();
		void GetUp();
		void HandOff();
		void FakeHandOff();
		void Toss();
		void Snap();
		void Throw();
		void Punt();
		void Kick();
		void AimKick();
		void Placehold();
		void Celebrate();
		void Complain();

		void GetBall();
		void HandOverBall(PLAYER_OBJ * target);
		void TossBallToPlayer(PLAYER_OBJ * player);
		void ThrowBallToReceiver();
		void PuntBall();
		void KickBall();
		void TryToTakeDown();
		void TryToBreakGrapple();
		void TryToCatch();
		void TryToCatchSnap();
	

		void Damage(float amt);



	public:

		void BeginActions();					
		void BeginPreHikeActions()		{ Actions.Clear(); Actions = PreHikeActions; BeginActions(); }
		void BeginPostHikeActions()		{ Actions.Clear(); Actions = PostHikeActions; BeginActions(); }

		void DoAction();
		void DoNextAction();

		void DoAction_RunToss(float xdir, float ydir);
		void DoAction_RunTo(float xoffset, float yoffset);
		void DoAction_SpyTarget();
		void DoAction_RunToCatchBall();
		void DoAction_CatchBall();
		void DoAction_Block();
		void DoAction_HandOff(PLAYER_OBJ * target);
		void DoAction_FakeHandOff(PLAYER_OBJ * target);
		void DoAction_Toss(PLAYER_OBJ * target);
		void DoAction_Snap();
		void DoAction_Placehold();
		void DoAction_WaitForSnapQB();
		void DoAction_WaitForSnapPH();
		void DoAction_RunToBallHolder();
		void DoAction_Spike();
		void DoAction_Kneel();
		void DoAction_PlaceHold();
		void DoAction_Kick();
		void DoAction_AimKick();
		void DoAction_Punt();
		void DoAction_FindReceiver();
		void DoAction_FindClosestReceiver();
		void DoAction_LineUpToReceiver();
		void DoAction_WaitForReceiver(float distx, float disty);
		void DoAction_WaitForAnyReceiver(float distx, float disty);
		void DoAction_SafetyWaitHigh(float distx, float disty, int mincover);
		void DoAction_SafetyWaitLow(float distx, float disty, int mincover);
		void DoAction_CoverReceiver(float distx, float disty);
		void DoAction_CatchPunt();
		void DoAction_BlockForBallHolder();
		void DoAction_TackleBallHolder();
		void DoAction_RecoverFumble();


	public: 

		ACTIONS PreHikeActions;
		ACTIONS PostHikeActions;
		

	public:
		
		void SetTrackTarget(PLAYER_OBJ * target)	{ TrackTarget = target; TrackCount = 0; }
		PLAYER_OBJ	* TrackTarget;
		int TrackCount;

		BOOL AddGrappler(PLAYER_OBJ * target);
		void RemoveGrappler(PLAYER_OBJ * target);
		void RemoveAllGrapplers()					{ NumGrapplers = 0; }

		PLAYER_OBJ	* GrappleTarget;
		PLAYER_OBJ	* Grapplers[MAX_GRAPPLERS];
		int NumGrapplers;

		int PadNum;


	public:

		BOOL RollForCatch();
		BOOL RollForCatchSnap();
		BOOL RollForGrappleBreak(PLAYER_OBJ * target);
		BOOL RollForTakeDown();

		int TimeToPosition(float xpos, float ypos);
		void GetDirectionToSpot(float xpos, float ypos, float * pxdir, float * pydir);
		float GetDistanceToSpot(float xpos, float ypos);
		int GetNumberOfDefendersNear();

		BOOL IsPlayerInRange(PLAYER_OBJ * target, float distx, float disty);
		

		PLAYER_OBJ * FindNearestPlayerToBlock();
		PLAYER_OBJ * FindUntargetedReceiver();
		PLAYER_OBJ * FindClosestReceiver();
		PLAYER_OBJ * FindClosestUntargetedReceiver();
	};



#endif