#ifndef __MATHUTILS_H
#define __MATHUTILS_H


int Round(float val);
int QuadraticFormula(float a, float b, float c, float * x1, float * x2);


#endif