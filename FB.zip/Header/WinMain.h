#ifndef __MAIN_H
#define __MAIN_H


LRESULT CALLBACK WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);


#endif