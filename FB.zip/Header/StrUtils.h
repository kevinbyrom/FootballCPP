#ifndef __STRUTILS_H
#define __STRUTILS_H


void RTrim(char * string, int slen);


#endif