#include <windows.h>
#include <math.h>
#include <stdio.h>
#include "PlayerObj.h"
#include "Football.h"
#include "MathUtils.h"




////////////////
// Animations //
////////////////


int RunAnim[]		= { 0,1,0,2,ANIM_LOOP,0 };
int GrappleAnim[]	= { 0,1,ANIM_LOOP,0 };
int ThrowAnim[]		= { 0,1,ANIM_LOOP,0 };
int CelebrateAnim[]	= { 0,1,ANIM_LOOP,0 };
int ComplainAnim[]	= { 0,1,ANIM_LOOP,0 };
int LeapAnim[]		= { 1,ANIM_LOOP,0 };
int SitAnim[]		= { 0,1,ANIM_LOOP,0};





PLAYER_OBJ::PLAYER_OBJ()
	{
	
	/////////////////////////////
	//						   //
	// Base Player Constructor //
	//						   //
	/////////////////////////////

	SetSide(); 

	Friction	= .01;

	Width		= 44;
	Height		= 44;
	SprOffset.X	= -22;
	SprOffset.Y = -44;

	SetNumBounds(3);
	SetBounds(0, PLAYER_WIDTH / 2, 0.0f, 0.0f, 0.0f);
	SetBounds(1, PLAYER_WIDTH / 2, 0.0f, 0.0f, -(PLAYER_HEIGHT / 2));
	SetBounds(2, PLAYER_WIDTH / 2, 0.0f, 0.0f, -(PLAYER_HEIGHT));

	InputEnabled = TRUE;

	PadNum = 0;

	FaceDir = DIR_RIGHT;

	ThrowType	= THROW_TYPE_NORMAL;
	}





void PLAYER_OBJ::Update()
	{

	//////////////////////////////
	//							//
	// The main update function //
	//							//
	//////////////////////////////


	ProcessControl();
	UpdateState();
	UpdateDeltas();
	UpdateAnimation();
	UpdateMove();


	// Update the track count 

	TrackCount++;


	// Prevent the player Z value from going lower than zero

	if (Wld.Z < 0) Wld.Z = 0;


	// Prevent the player from going out of the endzone bounds

	if (Wld.X >= ENDZONE_SIDELINE_POS) 
		{
		Wld.X = ENDZONE_SIDELINE_POS - 1;
		Delta.X = 0;
		}
	
	if (Wld.X <= -ENDZONE_SIDELINE_POS) 
		{
		Wld.X = -ENDZONE_SIDELINE_POS + 1;
		Delta.X = 0;
		}




	if (!DownInfo.Done)
		{
		if (HasBall)
			{
			// Check for passed scrimmage

			if (!DownInfo.PassedScrimmage &&
				((GameInfo.Direction[TeamNum] == DIR_LEFT && Wld.X <= DownInfo.ScrimmagePos) ||
				(GameInfo.Direction[TeamNum] == DIR_RIGHT && Wld.X >= DownInfo.ScrimmagePos)))
				{
				SendMessageToGroup(MESSAGE_DEST_ALL, MSG_BALL_PASSED_SCRIMMAGE, 0, (DWORD)this);
				}


			// Check for touchdown

			if ((GameInfo.Direction[TeamNum] == DIR_LEFT && (Wld.X - (Width / 2) <= -ENDZONE_POS)) ||
				(GameInfo.Direction[TeamNum] == DIR_RIGHT && (Wld.X + (Width / 2) >= ENDZONE_POS)))
					SendMessageToGroup(MESSAGE_DEST_ALL, MSG_TOUCHDOWN, 0, (DWORD)this);
			else if (Wld.Y <= -SIDELINE_POS || Wld.Y >= SIDELINE_POS)
				SendMessage(0, MSG_BALL_HOLDER_OUT_OF_BOUNDS, 0, (DWORD)this);
			}
		}	
	}





void PLAYER_OBJ::PrepareForPlay()
	{
	
	////////////////////////////////////////////////////
	//												  //
	// Used to prepare the player object for the play //
	//												  //
	////////////////////////////////////////////////////


	// Clear the actions 

	Actions.Clear();


	// Reset the flags 

	HasBall			= FALSE;
	InputEnabled	= TRUE;
	TrackTarget		= NULL;
	GrappleTarget	= NULL;

	
	// Set grapplers to zero

	NumGrapplers = 0;


	// Stand

	Stop();
	Stand();
	}





void PLAYER_OBJ::SetPlayerInfo(PLAYER_INFO * pi)
	{

	///////////////////////////////////////////////////////
	//													 //
	// Used to attach a PlayerInfo struct to this object //
	//													 //
	///////////////////////////////////////////////////////


	PlayerInfo = pi;

	if (PlayerInfo == NULL)
		return;


	// Set the max speed 

	//DestVel.X = ((PlayerInfo->Attrib.Speed.Value() * 9) / 100) * (9.8 / FPS);
	//DestVel.Y = ((PlayerInfo->Attrib.Speed.Value() * 9) / 100) * (9.8 / FPS);


	// Set the max acceleration

	//Acc.X = DestVel.X / (FPS * ((100 - PlayerInfo->Attrib.Accel.Value()) / 20));
	//Acc.Y = DestVel.Y / (FPS * ((100 - PlayerInfo->Attrib.Accel.Value()) / 20));
	}




//////////////////
// CONTROL CODE //
//////////////////




void PLAYER_OBJ::ProcessControl()
	{

	////////////////////////////////////////////////
	//											  //
	// Used to perform logic based on the current //
	// control type								  //
	//											  //
	////////////////////////////////////////////////


	switch(ControlType)
		{
		case CONTROL_USER:
			if (InputEnabled && Side[SideNum].Control == this)
				ProcessState(INPUT_STATE);
			break;


		case CONTROL_ACTIONS:
			DoControl_Action();
			break;
		}
	}





void PLAYER_OBJ::DoControl_Action()
	{

	//////////////////////////////////////////////////
	//												//
	// Used to process control from an action array //
	//												//
	//////////////////////////////////////////////////


	// Do nothing if there are no actions

	if (Actions.GetNumActions() == 0)
		return;


	// Do the current action 

	if (!Actions.IsDelayed())
		{
		DoAction();


		// If this is a time based action, and the time is met 
		// then do the next action 

		if (Actions.GetTime() != -1)
			{
			// Decrement the action time 

			Actions.DecrementTime(1);

			if (Actions.GetTime() <= 0)
				DoNextAction();
			}
		}
	else
		Actions.DecrementDelayTime(1);
	}




/**********************************************************************************

STATE CODE

***********************************************************************************/




void PLAYER_OBJ::ProcessState(int reason)
	{

	/////////////////////////
	//					   //
	// State machine logic //
	//					   //
	/////////////////////////


	CHECK_STATE()


	/////////////////
	// STAND STATE //
	/////////////////

	BEGIN_STATE(STATE_STAND)
		{

		ON_ENTER()
			{
			Stop();
			Animate(FALSE);
			}


		ON_UPDATE()
			{
			
			// Increase stamina a little

			Damage(STAND_DAMAGE);

			
			// Set the frame //

			Frame = FRAME_STAND + ((FaceDir - 1) * NUM_SPRTILES_X);
			}


		ON_INPUT()
			{
			float xdir = 0.0f;
			float ydir = 0.0f;


			// Check for running direction 

			if (VPad[PadNum].Left())
				xdir		= -1.0f;
			else if (VPad[PadNum].Right())
				xdir		= 1.0f;

			if (VPad[PadNum].Up())
				ydir		= -1.0f;
			else if (VPad[PadNum].Down())
				ydir		= 1.0f;

			if (xdir != 0 && ydir != 0)
				{
				xdir *= .71;
				ydir *= .71;
				}


			// Check for running 

			if (xdir != 0.0f || ydir != 0.0f)
				Run(xdir, ydir);


			// Check for passes && target receiver changes

			if (SideNum == OFFENSE && Flag.Passer && HasBall && !DownInfo.BallPassed && !DownInfo.PassedScrimmage)
				{
				if (VPad[PadNum].Button(0))
					{
					Stand();
					Throw();
					}
				else if (VPad[PadNum].ButtonClicked(1))
					{
					Side[SideNum].ChangeTargetReceiver();
					}
				}
			}


		ON_EXIT()
			{
			}
		}



	//////////////////
	// STANCE STATE //
	//////////////////

	
	BEGIN_STATE(STATE_STANCE)
		{

		ON_ENTER()
			{

			Animate(FALSE);
			Stop();
			}


		ON_UPDATE()
			{

			// Set the frame //
	
			//if (FaceDir == DIR_UP || FaceDir == DIR_UPLEFT || 
			//	FaceDir == DIR_LEFT || FaceDir == DIR_DOWNLEFT || FaceDir == DIR_DOWN)
			//	Frame = FRAME_STANCE + FRAME_AMT_STANCE;
			//else
				Frame = FRAME_STANCE + ((FaceDir - 1) * NUM_SPRTILES_X);
			}
		}



	///////////////
	// RUN STATE //
	///////////////


	BEGIN_STATE(STATE_RUN)
		{

		ON_ENTER()
			{
			SetAnimation(RunAnim);
			SetAnimationSpeed(10);
			SetAnimationPos(0);
			Animate(TRUE);


			// Set the acceleration and velocity //

			Acc.X = .05;
			Acc.Y = .05;

			DestVel.X = 2;
			DestVel.Y = 2;
			}


		ON_UPDATE()
			{

			// Damage the stamina a little

			Damage(RUN_DAMAGE);

			
			// Set the animation speed 

			if (TotalVel >= 1.5f)
				SetAnimationSpeed(10);
			else
				SetAnimationSpeed(20);


			// Set the frame //

			Frame = FRAME_RUN + ((FaceDir - 1) * NUM_SPRTILES_X) + Anim.Frame;
			}


		ON_INPUT()
			{

			BOOL  dirkeypressed	= FALSE;
			float xdir			= 0.0f;
			float ydir			= 0.0f;


			// Check for running direction 

			if (VPad[PadNum].Left())
				xdir		= -1.0f;
			else if (VPad[PadNum].Right())
				xdir		= 1.0f;

			if (VPad[PadNum].Up())
				ydir		= -1.0f;
			else if (VPad[PadNum].Down())
				ydir		= 1.0f;

			if (xdir != 0 && ydir != 0)
				{
				xdir *= .71;
				ydir *= .71;
				}

			dirkeypressed = (xdir != 0.0f || ydir != 0.0f);


			// Check for running 

			if (dirkeypressed)
				Run(xdir, ydir);


			// Check for standing 

			else 
				SlowStop();


			// Check for button 0 presses

			if (VPad[PadNum].Button(0))
				{
				if (Flag.Passer && HasBall && !DownInfo.BallPassed && !DownInfo.PassedScrimmage)
					{
					Stand();
					Throw();
					}
				else if (xdir != 0.0f || ydir != 0.0f)
					{
					Dive(xdir, ydir);
					}
				}

			// Check for button 1 clicks 

			if (VPad[PadNum].ButtonClicked(1))
				{
				if (Flag.Passer && HasBall && !DownInfo.BallPassed)
					{
					Side[OFFENSE].ChangeTargetReceiver();
					}
				}
			}
		}



	/////////////////////
	// SLOW DOWN STATE //
	/////////////////////


	BEGIN_STATE(STATE_SLOWDOWN)
		{

		ON_ENTER()
			{
			SetAnimation(RunAnim);
			SetAnimationSpeed(15);
			SetAnimationPos(0);
			Animate(TRUE);


			// Set the acceleration //

			Acc.X = 0.05f;
			Acc.Y = 0.05f;

			DestVel.X = 0;
			DestVel.Y = 0;
			}


		ON_UPDATE()
			{
			Frame = FRAME_RUN + ((FaceDir - 1) * NUM_SPRTILES_X) + Anim.Frame;
			}


		ON_INPUT()
			{
			BOOL  dirkeypressed	= FALSE;
			float xdir			= 0.0f;
			float ydir			= 0.0f;


			// Check for running direction 

			if (VPad[PadNum].Left())
				xdir		= -1.0f;
			else if (VPad[PadNum].Right())
				xdir		= 1.0f;

			if (VPad[PadNum].Up())
				ydir		= -1.0f;
			else if (VPad[PadNum].Down())
				ydir		= 1.0f;

			if (xdir != 0 && ydir != 0)
				{
				xdir *= .71;
				ydir *= .71;
				}

			dirkeypressed = (xdir != 0.0f || ydir != 0.0f);


			// Check for running 

			if (dirkeypressed)
				Run(xdir, ydir);


			// Check for standing 

			else if (TotalVel == 0.0f)
				{
				Stand();
				}


			// Check for button 0 presses

			if (VPad[PadNum].Button(0))
				{
				if (Flag.Passer && HasBall && !DownInfo.BallPassed && !DownInfo.PassedScrimmage)
					{
					Stand();
					Throw();
					}
				else if (xdir != 0.0f || ydir != 0.0f)
					{
					Dive(xdir, ydir);
					}
				}

			// Check for button 1 clicks 

			if (VPad[PadNum].ButtonClicked(1))
				{
				if (Flag.Passer && HasBall && !DownInfo.BallPassed)
					{
					Side[OFFENSE].ChangeTargetReceiver();
					}
				}
			}
		}



	////////////////
	// LEAP STATE //
	////////////////


	BEGIN_STATE(STATE_LEAP)
		{

		ON_ENTER()
			{
			// Set the leap animation 

			SetAnimation(LeapAnim);
			SetAnimationSpeed(3);
			SetAnimationPos(0);
			Animate(TRUE);

			// Set the Z delta 

			Delta.Z = 1.5;
			}


		ON_UPDATE()
			{
			
			// If the player has landed, set the state to stand

			if (Wld.Z == 0 && Vel.Z <= 0)
				Stand();


			// Set the frame 

			Frame = FRAME_LEAP + ((FaceDir - 1) * NUM_SPRTILES_X);
			}


		ON_INPUT()
			{
			}
		}



	////////////////
	// DIVE STATE //
	////////////////


	BEGIN_STATE(STATE_DIVE)
		{

		ON_ENTER()
			{
			SetAnimation(LeapAnim);
			SetAnimationSpeed(3);
			SetAnimationPos(0);
			Animate(TRUE);
			
			Acc.X		= 1;
			Acc.Y		= 1;

			DestVel.X	+= DIVE_SPEED;
			DestVel.Y	+= DIVE_SPEED;

			Vel.X		= DestVel.X;
			Vel.Y		= DestVel.Y;

			Wld.Z		= Height / 4;
			Delta.Z		= -GRAVITY;
			}


		ON_UPDATE()
			{

			// If the player has landed...

			if (Wld.Z == 0.0f && Vel.Z <= 0.0f)
				{

				// Slow down

				Acc.X		= 0.05f;
				Acc.Y		= 0.05f;
				DestVel.X	= 0.0f;
				DestVel.Y	= 0.0f;


				// If the player is stopped, set the state to sit

				if (TotalVel == 0.0f)
					{
					Stop();
					Sit();
					}
				}


			// Set the frame 

			Frame = FRAME_DIVE + ((FaceDir - 1) * NUM_SPRTILES_X);
			}
		}



	///////////////////
	// GRAPPLE STATE //
	///////////////////


	BEGIN_STATE(STATE_GRAPPLE)
		{

		ON_ENTER()
			{
			SetAnimation(GrappleAnim);
			SetAnimationSpeed(10);
			SetAnimationPos(0);
			Animate(TRUE);

			Stop();
			}


		ON_UPDATE()
			{
			// Every second, check for take downs

			if (StateCount >= FPS)
				{
				StateCount = 0;
				TryToTakeDown();
				}


			// Set the frame 

			//if (FaceDir == DIR_UP || FaceDir == DIR_UPLEFT || 
			//	FaceDir == DIR_LEFT || FaceDir == DIR_DOWNLEFT || FaceDir == DIR_DOWN)
			//	Frame = FRAME_GRAPPLE + FRAME_AMT_GRAPPLE + Anim.Frame;
			//else
				Frame = FRAME_GRAPPLE + ((FaceDir - 1) * NUM_SPRTILES_X) + Anim.Frame;
			}
		}



	/////////////////////////
	// BREAK GRAPPLE STATE //
	/////////////////////////


	BEGIN_STATE(STATE_BREAKGRAPPLE)
		{

		ON_ENTER()
			{
			SetAnimation(GrappleAnim);
			SetAnimationSpeed(10);
			SetAnimationPos(0);
			Animate(TRUE);

			Stop();
			}


		ON_UPDATE()
			{

			// Damage the stamina a little

			Damage(GRAPPLE_DAMAGE);


			// Every second, check for a grapple break

			if (StateCount >= FPS)
				{
				StateCount = 0;
				TryToBreakGrapple();
				}

			//if (FaceDir == DIR_UP || FaceDir == DIR_UPLEFT || 
			//	FaceDir == DIR_LEFT || FaceDir == DIR_DOWNLEFT || FaceDir == DIR_DOWN)
			//	Frame = FRAME_GRAPPLE + FRAME_AMT_GRAPPLE + Anim.Frame;
			//else
				Frame = FRAME_GRAPPLE + ((FaceDir - 1) * NUM_SPRTILES_X) + Anim.Frame;
			}


		ON_INPUT()
			{
			if (VPad[PadNum].ButtonClicked(0))
				TryToBreakGrapple();
			}
		}



	//////////////////
	// TUMBLE STATE //
	//////////////////


	BEGIN_STATE(STATE_TUMBLE)
		{

		ON_ENTER()
			{
			}


		ON_UPDATE()
			{
			}
		}



	///////////////////
	// LAYDOWN STATE //
	///////////////////


	BEGIN_STATE(STATE_LAYDOWN)
		{

		ON_ENTER()
			{
			Stop();
			}


		ON_UPDATE()
			{

			// If laying for a certain time, sit up

			if (StateCount >= FPS * 2)
				Sit();


			//if (FaceDir == DIR_UP || FaceDir == DIR_UPLEFT || 
			//	FaceDir == DIR_LEFT || FaceDir == DIR_DOWNLEFT || FaceDir == DIR_DOWN)
			//	Frame = FRAME_LAY + FRAME_AMT_LAY;
			//else
				Frame = FRAME_LAY + ((FaceDir - 1) * NUM_SPRTILES_X);
			}
		}



	///////////////
	// SIT STATE //
	///////////////


	BEGIN_STATE(STATE_SIT)
		{

		ON_ENTER()
			{
			SetAnimation(SitAnim);
			SetAnimationSpeed(FPS / 4);
			SetAnimationPos(0);
			Animate(TRUE);

			Stop();
			}


		ON_UPDATE()
			{

			// If the state count is greater than 2 seconds then getup

			if (StateCount >= FPS * 2)
				GetUp();

			
			// Set the frame 

			//if (FaceDir == DIR_UP || FaceDir == DIR_UPLEFT || 
			//	FaceDir == DIR_LEFT || FaceDir == DIR_DOWNLEFT || FaceDir == DIR_DOWN)
			//	Frame = FRAME_SIT + FRAME_AMT_SIT + Anim.Frame;
			//else
				Frame = FRAME_SIT + ((FaceDir - 1) * NUM_SPRTILES_X) + Anim.Frame;
			}
		}



	/////////////////
	// GETUP STATE //
	/////////////////


	BEGIN_STATE(STATE_GETUP)
		{

		ON_ENTER()
			{
			Animate(FALSE);
			Stop();
			}


		ON_UPDATE()
			{
			
			int frame;


			// If the state count is less than 1/6 a second, set the frame to the first frame

			if (StateCount < (FPS / 6))
				frame = 0;

			// Else if the state is less than 1/3 a second, set the frame to the second frame

			else if (StateCount < (FPS / 3))
				frame = 1;

			// Else set the state to STAND

			else
				Stand();

			
			//if (FaceDir == DIR_UP || FaceDir == DIR_UPLEFT || 
			//	FaceDir == DIR_LEFT || FaceDir == DIR_DOWNLEFT || FaceDir == DIR_DOWN)
			//	Frame = FRAME_GETUP + FRAME_AMT_GETUP + (frame * 2);
			//else
				Frame = FRAME_GETUP + ((FaceDir - 1) * NUM_SPRTILES_X) + (frame * 2);
			}
		}



	///////////////////
	// HANDOFF STATE //
	///////////////////


	BEGIN_STATE(STATE_HANDOFF)
		{

		ON_ENTER()
			{
			Animate(FALSE);
			Stop();
			StateTime = -1;
			}


		ON_UPDATE()
			{
			int frame;


			if (StateCount < FPS / 4)
				frame = 0;
			else
				{
				frame = 1;
				StateDone = TRUE;
				}


			//if (FaceDir == DIR_UP || FaceDir == DIR_UPLEFT || 
			//	FaceDir == DIR_LEFT || FaceDir == DIR_DOWNLEFT || FaceDir == DIR_DOWN)
			//	Frame = FRAME_HANDOFF + FRAME_AMT_HANDOFF + (frame * 2);
			//else
				Frame = FRAME_HANDOFF + ((FaceDir - 1) * NUM_SPRTILES_X) + frame;
			}
		}



	////////////////////////
	// FAKE HANDOFF STATE //
	////////////////////////


	BEGIN_STATE(STATE_FAKEHANDOFF)
		{

		ON_ENTER()
			{
			Animate(FALSE);
			Stop();
			StateTime = -1;
			}


		ON_UPDATE()
			{
			int frame;


			if (StateCount < FPS / 4)
				frame = 0;
			else
				{
				frame = 1;
				StateDone = TRUE;
				}


			//if (FaceDir == DIR_UP || FaceDir == DIR_UPLEFT || 
			//	FaceDir == DIR_LEFT || FaceDir == DIR_DOWNLEFT || FaceDir == DIR_DOWN)
			//	Frame = FRAME_HANDOFF + FRAME_AMT_HANDOFF + (frame * 2);
			//else
				Frame = FRAME_HANDOFF + ((FaceDir - 1) * NUM_SPRTILES_X) + frame;
			}
		}



	////////////////////////
	// TOSS HANDOFF STATE //
	////////////////////////


	BEGIN_STATE(STATE_TOSS)
		{

		ON_ENTER()
			{
			Animate(FALSE);
			Stop();
			StateTime = -1;
			}


		ON_UPDATE()
			{
			int frame;


			if (StateCount < FPS / 4)
				frame = 0;
			else
				{
				frame = 1;
				
				StateDone = TRUE;
				}


			//if (FaceDir == DIR_UP || FaceDir == DIR_UPLEFT || 
			//	FaceDir == DIR_LEFT || FaceDir == DIR_DOWNLEFT || FaceDir == DIR_DOWN)
			//	Frame = FRAME_HANDOFF + FRAME_AMT_HANDOFF + (frame * 2);
			//else
				Frame = FRAME_HANDOFF + ((FaceDir - 1) * NUM_SPRTILES_X) + frame;
			}
		}



	////////////////
	// PUNT STATE //
	////////////////


	BEGIN_STATE(STATE_PUNT)
		{

		ON_ENTER()
			{
			Animate(FALSE);
			Stop();
			StateTime = -1;
			}


		ON_UPDATE()
			{
			int frame;


			if (StateCount < FPS / 4)
				frame = 0;
			else
				{
				frame = 1;
				
				StateDone = TRUE;
				}


			//if (FaceDir == DIR_UP || FaceDir == DIR_UPLEFT || 
			//	FaceDir == DIR_LEFT || FaceDir == DIR_DOWNLEFT || FaceDir == DIR_DOWN)
			//	Frame = FRAME_HANDOFF + FRAME_AMT_HANDOFF + (frame * 2);
			//else
				Frame = FRAME_HANDOFF + ((FaceDir - 1) * NUM_SPRTILES_X) + frame;
			}
		}




	////////////////
	// KICK STATE //
	////////////////


	BEGIN_STATE(STATE_KICK)
		{

		ON_ENTER()
			{
			Animate(FALSE);
			Stop();
			StateTime = -1;
			}


		ON_UPDATE()
			{
			int frame;


			if (StateCount < FPS / 4)
				frame = 0;
			else
				{
				frame = 1;
				
				StateDone = TRUE;
				}


			//if (FaceDir == DIR_UP || FaceDir == DIR_UPLEFT || 
			//	FaceDir == DIR_LEFT || FaceDir == DIR_DOWNLEFT || FaceDir == DIR_DOWN)
			//	Frame = FRAME_HANDOFF + FRAME_AMT_HANDOFF + (frame * 2);
			//else
				Frame = FRAME_HANDOFF + ((FaceDir - 1) * NUM_SPRTILES_X) + frame;
			}
		}




	////////////////////
	// AIM KICK STATE //
	////////////////////


	BEGIN_STATE(STATE_AIMKICK)
		{

		ON_ENTER()
			{
			SendMessage(0, MSG_START_AIM, 0, (DWORD)1.5f, 0);
			StateTime = -1;
			InputEnabled = TRUE;
			}


		ON_INPUT()
			{
			if (VPad[PadNum].ButtonClicked(0))
				StateDone = TRUE;
			}


		ON_EXIT()
			{
			InputEnabled = FALSE;
			}
		}



	////////////////
	// SNAP STATE //
	////////////////


	BEGIN_STATE(STATE_SNAP)
		{
		ON_ENTER()
			{

			// Face the receiver 

			/*if (Side[SideNum].TargetRec->Wld.X > Wld.X)			
				Face(1.0f, 0.0f);
			else if (Side[SideNum].TargetRec->Wld.X < Wld.X)	
				Face(-1.0f, 0.0f);
			else															
				Face(1.0f, 0.0f);


			// Set the throw attributes 

			ThrowAcc = 90.0f;
			ThrowPow = 50.0f;
			ThrowCtr = 0.0f;*/


			// Stop movement

			Stop();
			}


		ON_UPDATE()
			{
			int frame = 2;


			// If the button is let go, finish throw

			/*if (StateCount < (FPS * .5))
				{
				if (VPad[PadNum].Button(0))
					ThrowCtr += 1.0f ;
				else
					StateCount = (FPS * .5);
				}


			if (StateCount < (FPS * .5))
				frame = 0;
			else if (StateCount < (FPS * .75))
				frame = 1;
			else if (StateCount < FPS)
				{
				frame = 2;
				
				if (HasBall)
					ThrowBallToReceiver();
				}
			else
				Stand();*/

			if (HasBall)
				{
				TossBallToPlayer(TrackTarget);
				Stand();
				Actions.Pop();
				}

			/*if (StateCount >= FPS * .5)
				{
				Stand();
				Actions.Pop();
				}


			//if (FaceDir == DIR_UP || FaceDir == DIR_UPLEFT || 
			//	FaceDir == DIR_LEFT || FaceDir == DIR_DOWNLEFT || FaceDir == DIR_DOWN)
			//	Frame = FRAME_THROW + FRAME_AMT_THROW + (frame * 2);
			//else
				Frame = FRAME_THROW + ((FaceDir - 1) * NUM_SPRTILES_X) + (frame * 2);*/
			}


		ON_INPUT()
			{
			}
		}



	/////////////////
	// THROW STATE //
	/////////////////


	BEGIN_STATE(STATE_THROW)
		{
		ON_ENTER()
			{

			// Face the receiver 

			if (Side[SideNum].TargetRec->Wld.X > Wld.X)			
				Face(1.0f, 0.0f);
			else if (Side[SideNum].TargetRec->Wld.X < Wld.X)	
				Face(-1.0f, 0.0f);
			else															
				Face(1.0f, 0.0f);


			// Set the throw attributes 

			ThrowAcc = 90.0f;
			ThrowPow = 50.0f;
			ThrowCtr = 0.0f;


			// Stop movement

			Stop();
			}


		ON_UPDATE()
			{
			int frame = 2;


			// If the button is let go, finish throw

			if (StateCount < (FPS * .5))
				{
				if (VPad[PadNum].Button(0))
					ThrowCtr += 1.0f ;
				else
					StateCount = (FPS * .5);
				}


			if (StateCount < (FPS * .5))
				frame = 0;
			else if (StateCount < (FPS * .75))
				frame = 1;
			else if (StateCount < FPS)
				{
				frame = 2;
				
				if (HasBall)
					ThrowBallToReceiver();
				}
			else
				Stand();



			ThrowPow = 100;
			//ThrowAcc += 1;
			//ThrowCtr += 1;


			if (ThrowPow > 100)	
				ThrowPow = 100;


			//if (FaceDir == DIR_UP || FaceDir == DIR_UPLEFT || 
			//	FaceDir == DIR_LEFT || FaceDir == DIR_DOWNLEFT || FaceDir == DIR_DOWN)
			//	Frame = FRAME_THROW + FRAME_AMT_THROW + (frame * 2);
			//else
				Frame = FRAME_THROW + ((FaceDir - 1) * NUM_SPRTILES_X) + (frame * 2);
			}


		ON_INPUT()
			{
			}
		}



	/////////////////////
	// PLACEHOLD STATE //
	/////////////////////


	BEGIN_STATE(STATE_PLACEHOLD)
		{

		ON_ENTER()
			{
			//SetAnimation(CelebrateAnim);
			//SetAnimationSpeed(3);
			//SetAnimationPos(0);
			//Animate(TRUE);

			Stop();
			}


		ON_UPDATE()
			{
			int frame = 2;


			// If the button is let go, finish throw

			if (StateCount < (FPS * .5))
				{
				if (VPad[PadNum].Button(0))
					ThrowCtr += 1.0f ;
				else
					StateCount = (FPS * .5);
				}


			if (StateCount < (FPS * .5))
				frame = 0;
			else if (StateCount < (FPS * .75))
				frame = 1;
			else if (StateCount < FPS)
				{
				frame = 2;
				
				StateDone = TRUE;
				}
			else
				Stand();

			Frame = FRAME_THROW + ((FaceDir - 1) * NUM_SPRTILES_X) + (frame * 2);
			}
		}




	/////////////////////
	// CELEBRATE STATE //
	/////////////////////


	BEGIN_STATE(STATE_CELEBRATE)
		{

		ON_ENTER()
			{
			SetAnimation(CelebrateAnim);
			SetAnimationSpeed(3);
			SetAnimationPos(0);
			Animate(TRUE);

			Stop();
			}


		ON_UPDATE()
			{
			}
		}



	////////////////////
	// COMPLAIN STATE //
	////////////////////


	BEGIN_STATE(STATE_COMPLAIN)
		{

		ON_ENTER()
			{
			SetAnimation(CelebrateAnim);
			SetAnimationSpeed(3);
			SetAnimationPos(0);
			Animate(TRUE);

			Stop();
			}


		ON_UPDATE()
			{
			}
		}
	}




void PLAYER_OBJ::Stand()
	{

	///////////////////////////////////
	//								 //
	// Used to make the player stand //
	//								 //
	///////////////////////////////////


	// Set the state to Stand
	
	SetState(STATE_STAND);
	}





void PLAYER_OBJ::Stance()
	{

	//////////////////////////////////////////////
	//								            //
	// Used to make the player go into a stance //
	//								            //
	//////////////////////////////////////////////


	// Set the state to stance

	SetState(STATE_STANCE);
	}





void PLAYER_OBJ::Run(float xdir, float ydir)
	{

	/////////////////////////////////
	//							   //
	// Used to make the player run //
	//							   //
	/////////////////////////////////


	// Only allow running if the player CAN run 

	if (State != STATE_STANCE && 
		State != STATE_STAND && 
		State != STATE_RUN && 
		State != STATE_SLOWDOWN)
		return;


	// Set the state to run //

	SetState(STATE_RUN);



	// Set the new move direction //

	MoveDir.X = xdir;
	MoveDir.Y = ydir;


	// Set the face direction //

	FaceMoveDirection();
	}





void PLAYER_OBJ::Leap(float xdir, float ydir)
	{

	//////////////////////////////////
	//								//
	// Used to make the player leap //
	//								//
	//////////////////////////////////


	// Only allow leaping if the player CAN leap 

	if (State != STATE_STAND && State != STATE_RUN)
		return;


	// Set the state to leap

	SetState(STATE_LEAP);


	// Set the face direction 
	
	Face(xdir, ydir);	
	}





void PLAYER_OBJ::Dive(float xdir, float ydir)
	{

	//////////////////////////////////
	//								//
	// Used to make the player dive //
	//								//
	//////////////////////////////////


	// Only allow player to dive if he CAN dive

	if (State != STATE_STAND && State != STATE_RUN)
		return;


	// Set the state to dive

	SetState(STATE_DIVE);


	// Set the move direction 

	MoveDir.X	= xdir;
	MoveDir.Y	= ydir;


	// Set the face direction 
	
	FaceMoveDirection();
	}





void PLAYER_OBJ::Grapple(float xdir, float ydir)
	{

	/////////////////////////////////////
	//								   //
	// Used to make the player grapple //
	//								   //
	/////////////////////////////////////


	// Set the state to grapple

	SetState(STATE_GRAPPLE);


	// Face the grappler

	Face(xdir, ydir);
	}





void PLAYER_OBJ::BreakGrapple(float xdir, float ydir)
	{

	/////////////////////////////////////
	//								   //
	// Used to make the player grapple //
	//								   //
	/////////////////////////////////////


	// Set the state to break grapple

	SetState(STATE_BREAKGRAPPLE);


	// Face the grappler

	Face(xdir, ydir);
	}





void PLAYER_OBJ::Tumble(float xdir, float ydir)
	{

	////////////////////////////////////
	//							      //
	// Used to make the player tumble //
	//							      //
	////////////////////////////////////
	}





void PLAYER_OBJ::LayDown()
	{

	//////////////////////////////////////
	//							        //
	// Used to make the player lay down //
	//							        //
	//////////////////////////////////////


	// Set the state to lay down

	SetState(STATE_LAYDOWN);
	}





void PLAYER_OBJ::Sit()
	{

	/////////////////////////////////
	//							   //
	// Used to make the player sit //
	//							   //
	/////////////////////////////////


	// Only allow the player to sit if he CAN sit

	if (State != STATE_LAYDOWN && State != STATE_DIVE)
		return;


	// Set the state to sit

	SetState(STATE_SIT);
	}





void PLAYER_OBJ::GetUp()
	{

	////////////////////////////////////
	//							      //
	// Used to make the player get up //
	//							      //
	////////////////////////////////////


	// Only allow the player to get up if he CAN get up

	if (State != STATE_SIT)
		return;


	// Set the state to get up

	SetState(STATE_GETUP);
	}





void PLAYER_OBJ::HandOff()
	{

	//////////////////////////////////////////
	//										//
	// Used to make the player do a handoff //
	//										//
	//////////////////////////////////////////


	// Set the state to handoff

	SetState(STATE_HANDOFF);
	}





void PLAYER_OBJ::FakeHandOff()
	{

	///////////////////////////////////////////////
	//											 //
	// Used to make the player do a fake handoff //
	//											 //
	///////////////////////////////////////////////


	// Set the state to fake handoff

	SetState(STATE_FAKEHANDOFF);
	}





void PLAYER_OBJ::Toss()
	{

	///////////////////////////////////////////
	//										 //
	// Used to make the player toss the ball //
	//										 //
	///////////////////////////////////////////


 	SetState(STATE_TOSS);
	}




void PLAYER_OBJ::Snap()
	{

	///////////////////////////////////////////
	//										 //
	// Used to make the player snap the ball //
	//										 //
	///////////////////////////////////////////


	// Set the state to snap

	SetState(STATE_SNAP);
	}




void PLAYER_OBJ::Throw()
	{

	/////////////////////////////////////////////////////
	//												   //
	// Used to make the player throw to another player //
	//												   //
	/////////////////////////////////////////////////////


	// Set the state to throw

	SetState(STATE_THROW);
	}





void PLAYER_OBJ::Punt()
	{

	///////////////////////////////////////////
	//										 //
	// Used to make the player punt the ball //
	//										 //
	///////////////////////////////////////////


	// Set the state to punt

	SetState(STATE_PUNT);
	}





void PLAYER_OBJ::Kick()
	{

	///////////////////////////////////////////
	//										 //
	// Used to make the player kick the ball //
	//										 //
	///////////////////////////////////////////


	// Set the state to kick

	SetState(STATE_KICK);
	}





void PLAYER_OBJ::AimKick()
	{

	//////////////////////////////////////////
	//										//
	// Used to make the player aim the kick //
	//										//
	//////////////////////////////////////////


	// Set the state to aim kick

	SetState(STATE_AIMKICK);
	}




void PLAYER_OBJ::GetBall()
	{

	///////////////////////////////////////////////////////////
	//														 //
	// Used to set the possession of the ball to this player //
	//														 //
	///////////////////////////////////////////////////////////


	Ball.Caught(this);
	HasBall = TRUE;
	}




void PLAYER_OBJ::HandOverBall(PLAYER_OBJ * target)
	{

	//////////////////////////////////////////////
	//											//
	// Used to hand over the ball to the target //
	//											//
	//////////////////////////////////////////////


	HasBall = FALSE;

	SendMessage(target->GetMsgTargetID(), MSG_HANDOFF_GIVEN);
	}




void PLAYER_OBJ::TossBallToPlayer(PLAYER_OBJ * player)
	{

	/////////////////////////////////////
	//								   //
	// Used to toss a ball to a player //
	//								   //
	/////////////////////////////////////


	float distpx,		// X Distance to player
		  distpy,		// Y Distance to player
		  distp;		// Total Distance to player

	float destx,		// X Destination
		  desty,		// Y Destination
		  distx,		// X Distance to destination
		  disty;		// Y Distance to destination

	float errorx,		// Error X (Based on accuracy)
		  errory;		// Error Y (Based on accuracy)

	float distance;		// Distance to destination
	int   lead;			// Pass lead
	int	  time;			// Time in frames
	
	int	  acc;			// Accuracy

	float xdir,			// Ball X direction
		  ydir,			// Ball Y direction
		  zdir;			// Ball Z direction



	// Calculate the distance between the players 

	distpx = Wld.X - player->Wld.X;
	distpy = Wld.Y - player->Wld.Y;
	distp = sqrt((distpx * distpx) + (distpy * distpy));


	// Calculate the time in frames for the ball to hit the destination 
	// Based on the throw type of the passer

	//lead = THROW_SPEED_NORMAL;
	//lead = FPS - (ThrowCtr * 2);

	//if (lead > THROW_SPEED_LOB)		lead = THROW_SPEED_LOB;
	//if (lead < THROW_SPEED_BULLET)	lead = THROW_SPEED_BULLET;
//	lead = THROW_SPEED_BULLET;
	lead = 0;

	time = lead + ((distp - 30) / 5);


	// Calculate the destination & distances to destination

	//acc = 100 - int(ThrowAcc);

	//if (acc == 0) acc = 1;
	
	acc = 1;

	errorx = 0;//((rand() % 10) - 5) + ((rand() % int(acc * 2)) - acc);
	errory = 0;//((rand() % 10) - 5) + ((rand() % int(acc * 2)) - acc);

	destx = player->Wld.X + (player->Delta.X * time) + errorx;
	desty = player->Wld.Y + (player->Delta.Y * time) + errory;

	distx = destx - Wld.X;
	disty = desty - Wld.Y;


	// Calculate the distance to the destination

	distance	= sqrt((distx * distx) + (disty * disty));


	// Calculate the ball vector 

	if (time == 0)
		time = 2;

	xdir = distx / time;
	ydir = disty / time;
	zdir = ((distance * GRAVITY) / (2 * (distance / time))) + (GRAVITY / 2);

	

	//if (ThrowPow == 0) ThrowPow = 1.0f;

	//xdir *= ThrowPow / 100;
	//ydir *= ThrowPow / 100;
	//zdir *= ThrowPow / 100;

	xdir *= .5;
	ydir *= .5;
	zdir *= .5;


	// Throw the ball

	Ball.Toss(xdir, ydir, zdir);


	// Set the has ball flag to false

	HasBall = FALSE;
	}




void PLAYER_OBJ::ThrowBallToReceiver()
	{
	float distpx,		// X Distance to player
		  distpy,		// Y Distance to player
		  distp;		// Total Distance to player

	float destx,		// X Destination
		  desty,		// Y Destination
		  distx,		// X Distance to destination
		  disty;		// Y Distance to destination

	float errorx,		// Error X (Based on accuracy)
		  errory;		// Error Y (Based on accuracy)

	float distance;		// Distance to destination
	int   lead;			// Pass lead
	int	  time;			// Time in frames
	
	int	  acc;			// Accuracy

	float xdir,			// Ball X direction
		  ydir,			// Ball Y direction
		  zdir;			// Ball Z direction

	PLAYER_OBJ * receiver = Side[SideNum].TargetRec;


	// Calculate the distance between the players 

	distpx = Wld.X - receiver->Wld.X;
	distpy = Wld.Y - receiver->Wld.Y;
	distp = sqrt((distpx * distpx) + (distpy * distpy));


	// Calculate the time in frames for the ball to hit the destination 
	// Based on the throw type of the passer

	switch(ThrowType)
		{
		case THROW_TYPE_LOB:
			lead = THROW_SPEED_LOB;
			break;

		case THROW_TYPE_NORMAL:
			lead = THROW_SPEED_NORMAL;
			break;

		case THROW_TYPE_BULLET:
			lead = THROW_SPEED_BULLET;
			break;
		}

	lead = FPS - (ThrowCtr * 2);

	if (lead > THROW_SPEED_LOB)		lead = THROW_SPEED_LOB;
	if (lead < THROW_SPEED_BULLET)	lead = THROW_SPEED_BULLET;
//	lead = THROW_SPEED_BULLET;

	time = lead + ((distp - 30) / 5);


	// Calculate the destination & distances to destination

	acc = 100 - int(ThrowAcc);

	if (acc == 0) acc = 1;
	
	errorx = ((rand() % 10) - 5) + ((rand() % int(acc * 2)) - acc);
	errory = ((rand() % 10) - 5) + ((rand() % int(acc * 2)) - acc);

	destx = receiver->Wld.X + (receiver->Delta.X * time) + errorx;
	desty = receiver->Wld.Y + (receiver->Delta.Y * time) + errory;

	distx = destx - Wld.X;
	disty = desty - Wld.Y;


	// Calculate the distance to the destination

	distance	= sqrt((distx * distx) + (disty * disty));


	// Calculate the ball vector 

	xdir = distx / time;
	ydir = disty / time;
	zdir = ((distance * GRAVITY) / (2 * (distance / time))) + (GRAVITY / 2);

	
	if (ThrowPow == 0) ThrowPow = 1.0f;

	xdir *= ThrowPow / 100;
	ydir *= ThrowPow / 100;
	zdir *= ThrowPow / 100;


	// Throw the ball

	Ball.Throw(xdir, ydir, zdir);


	// Set the ball thrown flag 

	DownInfo.BallPassed = TRUE;


	// Set the has ball flag to false

	HasBall = FALSE;


	// Inform the players the ball has been thrown 
	
	SendMessageToGroup(MESSAGE_DEST_ALL, MSG_BALL_THROWN, 0, time);
	}





void PLAYER_OBJ::PuntBall()
	{

	///////////////////////////
	//						 //
	// Used to punt the ball //
	//						 //
	///////////////////////////


	float spotx,
		  spoty;

	float distsx,		// X Distance to spot
		  distsy,		// Y Distance to spot
		  dists;		// Total Distance to spot

	float destx,		// X Destination
		  desty,		// Y Destination
		  distx,		// X Distance to destination
		  disty;		// Y Distance to destination

	float errorx,		// Error X (Based on accuracy)
		  errory;		// Error Y (Based on accuracy)

	float distance;		// Distance to destination
	int   lead;			// Pass lead
	int	  time;			// Time in frames
	
	int	  acc;			// Accuracy

	float xdir,			// Ball X direction
		  ydir,			// Ball Y direction
		  zdir;			// Ball Z direction



	// Calculate the landing spot

	if (Side[SideNum].Direction == DIR_LEFT)
		spotx = Wld.X - (YARD_DISTANCE * 40);
	else
		spotx = Wld.X + (YARD_DISTANCE * 40);


	spoty = 0.0f;


	// Calculate the distance between the spot 

	distsx = Wld.X - spotx;
	distsy = Wld.Y - spoty;
	dists = sqrt((distsx * distsx) + (distsy * distsy));


	// Calculate the time in frames for the ball to hit the destination 
	// Based on the throw type of the passer

	//lead = THROW_SPEED_NORMAL;
	//lead = FPS - (ThrowCtr * 2);

	//if (lead > THROW_SPEED_LOB)		lead = THROW_SPEED_LOB;
	//if (lead < THROW_SPEED_BULLET)	lead = THROW_SPEED_BULLET;
//	lead = THROW_SPEED_BULLET;
	lead = 60;

	time = lead + ((dists - 30) / 5);


	// Calculate the destination & distances to destination

	//acc = 100 - int(ThrowAcc);

	//if (acc == 0) acc = 1;
	
	acc = 1;

	errorx = 0;//((rand() % 10) - 5) + ((rand() % int(acc * 2)) - acc);
	errory = 0;//((rand() % 10) - 5) + ((rand() % int(acc * 2)) - acc);

	destx = spotx;//player->Wld.X + (player->Delta.X * time) + errorx;
	desty = spoty;//player->Wld.Y + (player->Delta.Y * time) + errory;

	distx = destx - Wld.X;
	disty = desty - Wld.Y;


	// Calculate the distance to the destination

	distance	= sqrt((distx * distx) + (disty * disty));


	// Calculate the ball vector 

	xdir = distx / time;
	ydir = disty / time;
	zdir = ((distance * GRAVITY) / (2 * (distance / time))) + (GRAVITY / 2);

	

	//if (ThrowPow == 0) ThrowPow = 1.0f;

	//xdir *= ThrowPow / 100;
	//ydir *= ThrowPow / 100;
	//zdir *= ThrowPow / 100;

	//xdir *= 1;
	//ydir *= 1;
	//zdir *= 1;


	// Punt the ball

	Ball.Punt(xdir, ydir, zdir);


	// Set the has ball flag to false

	HasBall = FALSE;
	}




void PLAYER_OBJ::KickBall()
	{

	///////////////////////////
	//						 //
	// Used to kick the ball //
	//						 //
	///////////////////////////


	float spotx,
		  spoty;

	float distsx,		// X Distance to spot
		  distsy,		// Y Distance to spot
		  dists;		// Total Distance to spot

	float destx,		// X Destination
		  desty,		// Y Destination
		  distx,		// X Distance to destination
		  disty;		// Y Distance to destination

	float errorx,		// Error X (Based on accuracy)
		  errory;		// Error Y (Based on accuracy)

	float distance;		// Distance to destination
	int	  time;			// Time in frames
	
	int	  acc;			// Accuracy

	float xdir,			// Ball X direction
		  ydir,			// Ball Y direction
		  zdir;			// Ball Z direction



	// Calculate the landing spot

	
	spotx = Wld.X + ((DownInfo.KickAim.Wld.X - Wld.X) * 10);
	spoty = Wld.Y + ((DownInfo.KickAim.Wld.Y - Wld.Y) * 10);

	float hyp = sqrt((spotx * spotx) + (spoty * spoty));
	float ratio = hyp == 0 ? 0 : (YARD_DISTANCE * 50) / hyp;
	
	spotx = spotx * ratio;
	spoty = spoty * ratio;


	// Calculate the distance between the spot 

	distsx = Wld.X - spotx;
	distsy = Wld.Y - spoty;
	dists = sqrt((distsx * distsx) + (distsy * distsy));

	time = FPS / 2;//((dists - 30) / 5);


	// Calculate the destination & distances to destination

	//acc = 100 - int(ThrowAcc);

	//if (acc == 0) acc = 1;
	
	acc = 1;

	errorx = ((rand() % 10) - 5) + ((rand() % int(acc * 2)) - acc);
	errory = ((rand() % 10) - 5) + ((rand() % int(acc * 2)) - acc);

	destx = spotx;// + errorx;player->Wld.X + (player->Delta.X * time) + errorx;
	desty = spoty;// + errory;player->Wld.Y + (player->Delta.Y * time) + errory;

	distx = destx - Wld.X;
	disty = desty - Wld.Y;


	// Calculate the distance to the destination

	distance	= sqrt((distx * distx) + (disty * disty));


	// Calculate the ball vector 

	xdir = distx / time;
	ydir = disty / time;
	zdir = ((distance * GRAVITY) / (2 * (distance / time))) + (GRAVITY / 2);


	// Kick the ball

	Ball.Kick(xdir, ydir, zdir);


	// Set the has ball flag to false

	HasBall = FALSE;
	}




void PLAYER_OBJ::Placehold()
	{

	///////////////////////////////////////
	//									 //
	// Used to make the player placehold //
	//									 //
	///////////////////////////////////////

	

	SetState(STATE_CELEBRATE);
	}




void PLAYER_OBJ::Celebrate()
	{

	///////////////////////////////////////
	//									 //
	// Used to make the player celebrate //
	//									 //
	///////////////////////////////////////

	

	SetState(STATE_CELEBRATE);
	}





void PLAYER_OBJ::Complain()
	{

	//////////////////////////////////////
	//									//
	// Used to make the player complain //
	//									//
	//////////////////////////////////////


	SetState(STATE_COMPLAIN);
	}





void PLAYER_OBJ::TryToTakeDown()
	{

	//////////////////////////////////////////////
	//										    //
	// Used to make the player try to take down //
	//											//
	//////////////////////////////////////////////


	Damage(GRAPPLE_DAMAGE * 2);

	RollForTakeDown();
	}





void PLAYER_OBJ::TryToBreakGrapple()
	{

	//////////////////////////////////////////////////////
	//													//
	// Used to make the player try to break the grapple //
	//													//
	//////////////////////////////////////////////////////


	Damage(GRAPPLE_DAMAGE * 2);

	RollForGrappleBreak(Grapplers[0]);
	}





void PLAYER_OBJ::TryToCatch()
	{

	///////////////////////////////////////////////////
	//												 //
	// Used to make the player try to catch the ball //
	//												 //
	///////////////////////////////////////////////////


	if (RollForCatch())
		{
		SendMessageToGroup(MESSAGE_DEST_ALL, MSG_BALL_CAUGHT, 0, (DWORD)this);
		
		InputEnabled	= TRUE;
		ControlType		= CONTROL_USER;

		Side[SideNum].Control = this;

		GetBall();
		}
	}




void PLAYER_OBJ::TryToCatchSnap()
	{

	///////////////////////////////////////////////////
	//												 //
	// Used to make the player try to catch the snap //
	//												 //
	///////////////////////////////////////////////////


	if (RollForCatchSnap())
		{
		GetBall();
		}
	}




/////////////////
// ACTION CODE //
/////////////////




		
void PLAYER_OBJ::BeginActions()
	{ 

	//////////////////////////////////
	//								//
	// Used to begin action control //
	//								//
	//////////////////////////////////


	ControlType	= CONTROL_ACTIONS;

	DoAction();
	}





void PLAYER_OBJ::DoAction()
	{

	////////////////////////////////////////
	//									  //
	// Used to perform the current action //
	//									  //
	////////////////////////////////////////


	if (Actions.GetNumActions() == 0)
		return;


	switch(Actions.GetType())
		{
		case ACTION_STAND:
			Stand();
			break;

		case ACTION_STANCE:
			Stance();
			break;

		case ACTION_RUN:
			Run(GameInfo.Direction[TeamNum] == DIR_LEFT ? -Actions.GetParam(0) : Actions.GetParam(0), Actions.GetParam(1));
			break;

		case ACTION_RUN_TOSS:
			DoAction_RunToss(Actions.GetParam(0), Actions.GetParam(1));
			break;


		case ACTION_RUNTO:
			DoAction_RunTo(Actions.GetParam(0), Actions.GetParam(1));
			break;

		case ACTION_FACE:		
			Face(GameInfo.Direction[TeamNum] == DIR_LEFT ? -Actions.GetParam(0) : Actions.GetParam(0), Actions.GetParam(1));
			break;

		case ACTION_BLOCK:
			DoAction_Block();
			break;

		case ACTION_HANDOFF:
			DoAction_HandOff(Side[SideNum].Rusher);
			break;

		case ACTION_FAKE_HANDOFF:
			DoAction_FakeHandOff(Side[SideNum].Rusher);
			break;

		case ACTION_TOSS:
			DoAction_Toss(Side[SideNum].Rusher);
			break;

		case ACTION_SNAP:
 			DoAction_Snap();
			break;

		case ACTION_PUNT:
			DoAction_Punt();
			break;

		case ACTION_KICK:
			DoAction_Kick();
			break;

		case ACTION_START_AIM:
			DoAction_AimKick();
			break;

		case ACTION_END_AIM:
			SendMessage(0, MSG_END_AIM, (DWORD)1.0f, 0);
			Actions.Pop();
			Stand();
			break;

		case ACTION_WAIT_FOR_SNAP_QB:
			DoAction_WaitForSnapQB();
			break;

		case ACTION_WAIT_FOR_SNAP_PH:
			DoAction_WaitForSnapPH();
			break;

		case ACTION_PLACEHOLD:
			DoAction_Placehold();
			break;

		case ACTION_RUNTO_BALL_HOLDER:
			DoAction_RunToBallHolder();
			break;

		case ACTION_FIND_RECEIVER:
			SetTrackTarget(FindUntargetedReceiver());
			break;

		case ACTION_FIND_CLOSEST_RECEIVER:
			SetTrackTarget(FindClosestUntargetedReceiver());
			break;

		case ACTION_WAIT_FOR_RECEIVER:
			DoAction_WaitForReceiver((float)Actions.GetParam(0), (float)Actions.GetParam(1));
			break;

		case ACTION_WAIT_FOR_ANY_RECEIVER:
			DoAction_WaitForAnyReceiver((float)Actions.GetParam(0), (float)Actions.GetParam(1));
			break;

		case ACTION_SAFETY_WAIT_HIGH:
			DoAction_SafetyWaitHigh((float)Actions.GetParam(0), (float)Actions.GetParam(1), (int)Actions.GetParam(2));
			break;

		case ACTION_SAFETY_WAIT_LOW:
			DoAction_SafetyWaitLow((float)Actions.GetParam(0), (float)Actions.GetParam(1), (int)Actions.GetParam(2));
			break;

		case ACTION_COVER_RECEIVER:
			DoAction_CoverReceiver((float)Actions.GetParam(0), (float)Actions.GetParam(1));
			break;

		case ACTION_BLOCK_FOR_BALL_HOLDER:
			DoAction_BlockForBallHolder();
			break;

		case ACTION_TACKLE_BALL_HOLDER:
			DoAction_TackleBallHolder();
			break;

		case ACTION_CATCH_BALL:
			DoAction_CatchBall();
			break;

		case ACTION_RECOVER_FUMBLE:
			DoAction_RecoverFumble();
			break;

		case ACTION_TARGET_PASSER:
			SetTrackTarget(Side[SideNum].Passer);
			Actions.Pop();
			break;

		case ACTION_TARGET_RUSHER:
			SetTrackTarget(Side[SideNum].Rusher);
			Actions.Pop();
			break;

		case ACTION_TARGET_PLACEHOLDER:
			SetTrackTarget(Side[SideNum].Placeholder);
			Actions.Pop();			
			break;

		case ACTION_USER_CONTROL:
			Side[SideNum].ChangeUserControl(this);
			Actions.Pop();
			break;
		}
	}





void PLAYER_OBJ::DoNextAction()
	{

	/////////////////////////////////////
	//								   //
	// Used to perform the next action //
	//								   //
	/////////////////////////////////////


	// Increment the action position 

	Actions.Pop();


	// If at a valid action then perform it  

	if (Actions.GetNumActions() > 0)
		DoAction();
	}





void PLAYER_OBJ::DoAction_RunToss(float xdir, float ydir)
	{

	///////////////////////////////////////////////////////////////////////////
	//																		 //
	// Used to do the action : RunToss by running to the direction specified //
	// and catching the toss												 //
	//																		 //
	///////////////////////////////////////////////////////////////////////////


	Run(GameInfo.Direction[TeamNum] == DIR_LEFT ? -Actions.GetParam(0) : Actions.GetParam(0), Actions.GetParam(1));


	if (Collision(&Ball))
		{

		// Clear the actions

		Actions.Pop();


		// Add ACTION_DELAY and ACTION_CATCHBALL again


		// Try to catch the ball

		TryToCatch();
		}
	}




void PLAYER_OBJ::DoAction_RunTo(float xoffset, float yoffset)
	{

	////////////////////////////////////////////////////////////////////
	//																  //
	// Used to do the action : RunTo by running to the spot specified //
	// by the scrimmage pos plus the offsets						  //
	//																  //
	////////////////////////////////////////////////////////////////////


	float xpos, ypos;
	float xdir, ydir;


	// Calculate the x & y world positions to run to

	if (GameInfo.Direction[TeamNum] == DIR_LEFT)
		{
		xpos = DownInfo.ScrimmagePos - xoffset;
		ypos = yoffset;
		}
	else
		{
		xpos = DownInfo.ScrimmagePos + xoffset;
		ypos = yoffset;
		}


	// If the current coordinates of the player is within range of the dest then pop the action

	if (fabs(Wld.X - xpos) <= (Width / 4) && fabs(Wld.Y - ypos) <= (Width / 4))
		{
		Actions.Pop();
		}

	// Otherwise, continue to run to the spot

	else
		{
		GetDirectionToSpot(xpos, ypos, &xdir, &ydir);
		Run(xdir, ydir);
		}
	}





void PLAYER_OBJ::DoAction_SpyTarget()
	{
	}





void PLAYER_OBJ::DoAction_CatchBall()
	{

	/////////////////////////////////////////////////////
	//												   //
	// Used to do the action : CatchBall by running to //
	// and catching the ball						   //
	//												   //
	/////////////////////////////////////////////////////


	float dist,
		  dirx,
		  diry;


	// Return if grappling

	if (State == STATE_GRAPPLE || State == STATE_BREAKGRAPPLE)
		return;


	// Get the distance to the landing spot

	dist = GetDistanceToSpot(Dest.X, Dest.Y);


	// Get the direction to the landing spot

	GetDirectionToSpot(Dest.X, Dest.Y, &dirx, &diry);


	// If standing on the spot, then face the ball

	if (dist < Width / 4)
		{
		Stand();
		}
	else
		Run(dirx, diry);


	if (Collision(&Ball))
		{

		// Clear the actions

		Actions.Clear();


		// Add ACTION_DELAY and ACTION_CATCHBALL again


		// Try to catch the ball

		TryToCatch();
		}
	}





void PLAYER_OBJ::DoAction_Block()
	{

	//////////////////////////////////////////////////////////////
	//														    //
	// Used to do the action : Block by waiting for an opponent //
	// to get near the player and blocking him					//
	//														    //
	//////////////////////////////////////////////////////////////


	float dirx, diry;


	// If grappling, just return

	if (State == STATE_GRAPPLE || State == STATE_BREAKGRAPPLE)
		return;


	// If an opponent hasn't been found to block or the target is grappled find a new target

	if (TrackTarget == NULL || TrackTarget->State == STATE_BREAKGRAPPLE || TrackCount >= FPS * 2)
		{
		SetTrackTarget(FindNearestPlayerToBlock());

		if (TrackTarget == NULL)
			return;
		}


	// If standing or running...

	if (State == STATE_STAND || State == STATE_RUN || State == STATE_STANCE)
		{

		// If standing on the target, attempt to grapple him

		if (Collision(TrackTarget))
			{
			if (SendMessage(TrackTarget->GetMsgTargetID(), MSG_GRAPPLED, 0, (DWORD)this) == TRUE)
				{
				GetDirectionToSpot(TrackTarget->Wld.X, TrackTarget->Wld.Y, &dirx, &diry);
				
				GrappleTarget = TrackTarget;

				Grapple(dirx, diry);
				}
			}

		// Otherwise, run to the target

		else
			{
			float xdir, ydir, dist;

			dist = GetDistanceToSpot(TrackTarget->Wld.X, TrackTarget->Wld.Y);

			if (dist <= Width)
				{
				GetDirectionToSpot(TrackTarget->Wld.X, TrackTarget->Wld.Y, &xdir, &ydir);
				Run(xdir, ydir);
				}
			else
				{
				if (GameInfo.Direction[TeamNum] == DIR_LEFT)
					Face(-1.0f, 0.0f);
				else
					Face(1.0f, 0.0f);

				Stand();
				}
			}
		}
	}





void PLAYER_OBJ::DoAction_HandOff(PLAYER_OBJ * target)
	{

	////////////////////////////////////////////////////////////////
	//															  //
	// Used to perform the action : Handoff by performing the	  //
	// handoff state and handing the ball to the nearest receiver //
	//															  //
	////////////////////////////////////////////////////////////////


		
	// Start the handoff

	HandOff();


	// If handoff state reaches a certain time

	if (StateDone && Collision(target))
		{

		// Give the target the ball

		HandOverBall(target);

		Actions.Pop();

		Stand();
		}
	}





void PLAYER_OBJ::DoAction_FakeHandOff(PLAYER_OBJ * target)
	{

	////////////////////////////////////////////////////////////////
	//															  //
	// Used to perform the action : FakeHandoff by performing the //
	// handoff state											  //
	//															  //
	////////////////////////////////////////////////////////////////


	// Start the fake handoff

	FakeHandOff();


	// If fake handoff state reaches a certain time

	if (StateDone && Collision(target))
		{

		// Pop the current action

		Actions.Pop();

		Stand();
		}
	}





void PLAYER_OBJ::DoAction_Toss(PLAYER_OBJ * target)
	{

	/////////////////////////////////////////////////////////
	//													   //
	// Used to perform the action : Toss by performing the //
	// toss state										   //
	//													   //
	/////////////////////////////////////////////////////////


	// Start the handoff

	Toss();


	// If handoff state reaches a certain time

	if (StateDone)
		{

		// Toss the ball to the target

		TossBallToPlayer(target);

		Actions.Pop();

		Stand();
		}
	}




void PLAYER_OBJ::DoAction_Punt()
	{

	/////////////////////////////////////////////////////////
	//													   //
	// Used to perform the action : Punt by performing the //
	// punt state										   //
	//													   //
	/////////////////////////////////////////////////////////


	// Start the punt

	Punt();


	// If handoff state reaches a certain time

	if (StateDone)
		{

		// Punt the ball

		PuntBall();

		Actions.Pop();

		Stand();
		}
	}




void PLAYER_OBJ::DoAction_Snap()
	{

	/////////////////////////////////////////////////////////
	//													   //
	// Used to perform the action : Snap by performing the //
	// snap state										   //
	//													   //
	/////////////////////////////////////////////////////////


	Snap();
	}




void PLAYER_OBJ::DoAction_Placehold()
	{

	//////////////////////////////////////////////////////////////
	//															//
	// Used to perform the action : Placehold by performing the //
	// placehold state										    //
	//															//
	//////////////////////////////////////////////////////////////


	Placehold();


	if (StateDone)
		{
		Actions.Pop();
		}
	}





void PLAYER_OBJ::DoAction_WaitForSnapQB()
	{

	////////////////////////////////////////////////////////////////
	//															  //
	// Used to perform the action : WaitForSnap by performing the //
	// wait for snap state										  //
	//															  //
	////////////////////////////////////////////////////////////////



	// Return if grappling

	if (State == STATE_GRAPPLE || State == STATE_BREAKGRAPPLE)
		return;


	// Stand and wait

	Stand();


	if (Collision(&Ball))
		{
		// Try to catch the snap

		TryToCatchSnap();
		Actions.Pop();
		}
	}




void PLAYER_OBJ::DoAction_WaitForSnapPH()
	{

	////////////////////////////////////////////////////////////////
	//															  //
	// Used to perform the action : WaitForSnap by performing the //
	// wait for snap state										  //
	//															  //
	////////////////////////////////////////////////////////////////



	// Return if grappling

	if (State == STATE_GRAPPLE || State == STATE_BREAKGRAPPLE)
		return;


	// Stand and wait

	Stand();


 	if (Collision(&Ball))
		{
		// Try to catch the snap

		TryToCatchSnap();
		Actions.Pop();
		}
	}




void PLAYER_OBJ::DoAction_RunToBallHolder()
	{

	////////////////////////////////////////////////////////////////
	//															  //
	// Used to perform the action : RunToBallHolder by running to //
	// the ball holder											  //
	//															  //
	////////////////////////////////////////////////////////////////


	float xdir, ydir;


	if (Ball.Holder)
		{
		GetDirectionToSpot(Ball.Holder->Wld.X, Ball.Holder->Wld.Y, &xdir, &ydir);
		Run(xdir, ydir);
		}
	else
		Stand();
	}





void PLAYER_OBJ::DoAction_Spike()
	{

	/////////////////////////////////////////////////////////////
	//														   //
	// Used to perform the action : Spike by throwing the ball //
	// at the player's feet to stop the play				   //
	//														   //
	/////////////////////////////////////////////////////////////
	}





void PLAYER_OBJ::DoAction_Kneel()
	{

	////////////////////////////////////////////////////////////
	//														  //
	// Used to perform the action : Kneel by kneeling down to //
	// stop the play										  //
	//														  //
	////////////////////////////////////////////////////////////
	}





void PLAYER_OBJ::DoAction_PlaceHold()
	{

	///////////////////////////////////////////////////////////
	//														 //
	// Used to perform the action : PlaceHold by holding the //
	// ball in place										 //
	//														 //
	///////////////////////////////////////////////////////////
	}





void PLAYER_OBJ::DoAction_Kick()
	{

	///////////////////////////////////////////////////////////
	//														 //
	// Used to perform the action : Kick by kicking the ball //
	// towards the goal posts								 //
	//														 //
	///////////////////////////////////////////////////////////


	// Start the kick

	Kick();


	// If handoff state reaches a certain time

	if (StateDone)
		{

		// Punt the ball

		KickBall();

		Actions.Pop();

		Stand();
		}
	}





void PLAYER_OBJ::DoAction_AimKick()
	{

	//////////////////////////////////////////////////////////////
	//															//
	// Used to perform the action : AimKick by sending a		//
	// StartAIM Message to the play and waiting for a keypress	//
	//														    //
	//////////////////////////////////////////////////////////////



	AimKick();

	if (StateDone)
		{
		Actions.Pop();
		}
	}





void PLAYER_OBJ::DoAction_FindReceiver()
	{

	//////////////////////////////////////////////////////////
	//												        //
	// Used to perform the action : FindReceiver by finding //
	// the closest untargeted receiver                      //
	//												        //
	//////////////////////////////////////////////////////////
	}





void PLAYER_OBJ::DoAction_LineUpToReceiver()
	{

	/////////////////////////////////////////////////////////////
	//														   //
	// Used to perform the action : LineUpToReceiver by lining //
	// up to the targeted receiver							   //
	//														   //
	/////////////////////////////////////////////////////////////
	}





void PLAYER_OBJ::DoAction_WaitForReceiver(float distx, float disty)
	{

	/////////////////////////////////////////////////////////////////
	//															   //
	// Used to perform the action : WaitForReceiver by waiting for //
	// the receiver to get within dist range					   //
	//															   //
	/////////////////////////////////////////////////////////////////


	// If a receiver is not locked on, just return

	if (TrackTarget == NULL)
		return;


	// If both requirements are met, pop the action

	if (IsPlayerInRange(TrackTarget, distx, disty))
		Actions.Pop();
	}





void PLAYER_OBJ::DoAction_WaitForAnyReceiver(float distx, float disty)
	{

	////////////////////////////////////////////////////////////////////
	//																  //
	// Used to perform the action : WaitForAnyReceiver by waiting for //
	// any receiver to get within dist range						  //
	//																  //
	////////////////////////////////////////////////////////////////////


	}





void PLAYER_OBJ::DoAction_SafetyWaitHigh(float distx, float disty, int mincover)
	{

	///////////////////////////////////////////////////////////////////////////
	//																		 //
	// Used to perform the action : SafetyWaitHigh by waiting for any		 //
	// receiver to get near the safety who is on the upper part of the field //
	//																		 //
	///////////////////////////////////////////////////////////////////////////

	
	PLAYER_OBJ * target;
	int i;


	Stand();


	for (i = 0; i < MAX_SIDE_PLAYERS; i++)
		{

		target = &Side[!SideNum].Player[i];


		// Find a receiver in upper field

		if (target->Wld.Y < 0)
			{


			// Check if the receiver is in range
			
			if (IsPlayerInRange(target, distx, disty))
				{


				// Check if the number of defenders on receiver is less than mincover

				if (target->GetNumberOfDefendersNear() < mincover)
					{


					// Set the TrackTarget to the receiver

					TrackTarget = target;


					// Pop this action & return
					
					Actions.Pop();

					return;
					}
				}
			}
		}

	// Delay the action

	Actions.Delay(FPS / 4);
	}





void PLAYER_OBJ::DoAction_SafetyWaitLow(float distx, float disty, int mincover)
	{

	///////////////////////////////////////////////////////////////////////////
	//																		 //
	// Used to perform the action : SafetyWaitLow by waiting for any		 //
	// receiver to get near the safety who is on the lower part of the field //
	//																		 //
	///////////////////////////////////////////////////////////////////////////


	PLAYER_OBJ * target;
	int i;


	Stand();


	for (i = 0; i < MAX_SIDE_PLAYERS; i++)
		{

		target = &Side[!SideNum].Player[i];


		// Find a receiver in lower field

		if (target->Wld.Y >= 0)
			{


			// Check if the receiver is in range
			
			if (IsPlayerInRange(target, distx, disty))
				{


				// Check if the number of defenders on receiver is less than mincover

				if (target->GetNumberOfDefendersNear() < mincover)
					{


					// Set the TrackTarget to the receiver

					TrackTarget = target;


					// Pop this action & return
					
					Actions.Pop();

					return;
					}
				}
			}
		}


	// Delay the action

	Actions.Delay(FPS / 4);
	}







void PLAYER_OBJ::DoAction_CoverReceiver(float distx, float disty)
	{

	/////////////////////////////////////////////////////////////////
	//															   //
	// Used to perform the action : CoverReceiver by sticking with //
	// the targeted receiver and staying withing dist range		   //
	//															   //
	/////////////////////////////////////////////////////////////////


	float xdir, ydir;


	// If a receiver is not locked on, just return

	if (TrackTarget == NULL)
		return;


	// Get the direction to the receiver

	if (GameInfo.Direction[TeamNum] == DIR_LEFT)
		GetDirectionToSpot(TrackTarget->Wld.X + distx, TrackTarget->Wld.Y + disty, &xdir, &ydir);
	else
		GetDirectionToSpot(TrackTarget->Wld.X - distx, TrackTarget->Wld.Y + disty, &xdir, &ydir);

	Run(xdir, ydir);
	}





void PLAYER_OBJ::DoAction_CatchPunt()
	{

	/////////////////////////////////////////////////////////////
	//														   //
	// Used to perform the action : CatchPunt by moving to the //
	// ball catch spot to catch the punt					   //
	//														   //
	/////////////////////////////////////////////////////////////
	}





void PLAYER_OBJ::DoAction_BlockForBallHolder()
	{

	///////////////////////////////////////////////////////////
	//														 //
	// Used to do the action : BlockForBallHolder by finding //
	// the nearest unblocked opponent and grappling with him //
	//														 //
	///////////////////////////////////////////////////////////


	float dirx, diry;


	// If grappling, just return

	if (State == STATE_GRAPPLE || State == STATE_BREAKGRAPPLE)
		return;


	// If an opponent hasn't been found to block or the target is grappled find a new target

	if (TrackTarget == NULL || TrackTarget->State == STATE_BREAKGRAPPLE || TrackCount >= FPS * 3)
		{
		SetTrackTarget(FindNearestPlayerToBlock());

		if (TrackTarget == NULL)
			return;
		}


	// If standing or running...

	if (State == STATE_STAND || State == STATE_RUN)
		{

		// If standing on the target, attempt to grapple him

		if (Collision(TrackTarget))
			{
			if (SendMessage(TrackTarget->GetMsgTargetID(), MSG_GRAPPLED, 0, (DWORD)this) == TRUE)
				{
				GetDirectionToSpot(TrackTarget->Wld.X, TrackTarget->Wld.Y, &dirx, &diry);
				
				GrappleTarget = TrackTarget;

				Grapple(dirx, diry);
				}
			}

		// Otherwise, run to the target

		else
			{
			float xdir, ydir;

			GetDirectionToSpot(TrackTarget->Wld.X, TrackTarget->Wld.Y, &xdir, &ydir);
			Run(xdir, ydir);
			}
		}
	}





void PLAYER_OBJ::DoAction_TackleBallHolder()
	{

	/////////////////////////////////////////////////////////
	//													   //
	// Used to do the action : TackleBallHolder by chasing //
	// down and tackling the person holding the ball	   //
	//													   //
	/////////////////////////////////////////////////////////


	float dist,
		  dirx,
		  diry;


	// If grappling, just return

	if (State != STATE_STAND && State != STATE_RUN && State != STATE_STANCE)
		return;


	// Make sure TrackTarget is set

	if (TrackTarget == NULL)
		{
		if (Ball.Holder && Ball.Holder->SideNum != SideNum)
			TrackTarget = Ball.Holder;
		else
			return;
		}


	// Get the distance to the ball holder

	dist = GetDistanceToSpot(TrackTarget->Wld.X, TrackTarget->Wld.Y);


	// Get the direction to the ball holder

	GetDirectionToSpot(TrackTarget->Wld.X, TrackTarget->Wld.Y, &dirx, &diry);


	// Add in an influence factor

	//dirx = (dirx + TrackTarget->MoveDir.X) / 2;
	
	//if (TrackTarget->MoveDir.Y)
	//	diry = (diry + TrackTarget->MoveDir.Y) / 2;

	

	if (Collision(TrackTarget))
		{
		if (State == STATE_DIVE)
			{
			SendMessage(TrackTarget->GetMsgTargetID(), MSG_TACKLED, 0, (DWORD)this);
			Actions.Clear();
			Actions.PushEnd(ACTION_DELAY, FPS / 2);
			Actions.PushEnd(ACTION_TACKLE_BALL_HOLDER);
			}
		else
			{
			if (SendMessage(TrackTarget->GetMsgTargetID(), MSG_GRAPPLED, 0, (DWORD)this) == TRUE)
				{
				GetDirectionToSpot(TrackTarget->Wld.X, TrackTarget->Wld.Y, &dirx, &diry);
				
				GrappleTarget = TrackTarget;

				Grapple(dirx, diry);
				}
			}
		}
	else if (dist < Width && TrackTarget->PlayerInfo->Position != DEPTH_QB)
		Dive(dirx, diry);
	else
		Run(dirx, diry);


	Actions.Delay(FPS / 4);
	}





void PLAYER_OBJ::DoAction_RecoverFumble()
	{

	///////////////////////////////////////////////////////////
	//														 //
	// Used to do the action : RECOVERFUMBLE by chasing down //
	// the ball and picking it up							 //
	//														 //
	///////////////////////////////////////////////////////////


	float dist,
		  dirx,
		  diry;


	// Get the distance to the ball

	dist = GetDistanceToSpot(Ball.Wld.X, Ball.Wld.Y);


	// Get the direction to the ball 

	GetDirectionToSpot(Ball.Wld.X, Ball.Wld.Y, &dirx, &diry);
	

	if (dist < Ball.Width / 2)
		{
		SendMessageToGroup(MESSAGE_DEST_ALL, MSG_BALL_CAUGHT, 0, (DWORD)this);
		}
	else if (dist < Ball.Width * 2)
		Dive(dirx, diry);
	else
		Run(dirx, diry);
	}





////////////
// EVENTS //
////////////





DWORD PLAYER_OBJ::OnMessage(int from, int msg, DWORD data1, DWORD data2)
	{

	///////////////////////////////////
	//								 //
	// Used to handle message events //
	//								 //
	///////////////////////////////////


	switch(msg)
		{
		case MSG_BALL_HIKED:
			OnBallHiked();
			return 1;

		case MSG_BALL_THROWN:
			OnBallThrown((int)data1);
			return 1;

		case MSG_BALL_CAUGHT:
			OnBallReceived((PLAYER_OBJ *)data1);
			return 1;

		case MSG_BALL_PASSED_SCRIMMAGE:
			OnBallPassedScrimmage((PLAYER_OBJ *)data1);
			return 1;

		case MSG_TOUCHDOWN:
			OnTouchdown((PLAYER_OBJ *)data1);
			return 1;

		case MSG_PLAY_DEAD:
			OnPlayDead();
			return 1;

		case MSG_GRAPPLED:
			return OnGrappled((PLAYER_OBJ *)data1);

		case MSG_GRAPPLE_BROKEN:
			OnGrappleBroken((PLAYER_OBJ *)data1);
			return 1;

		case MSG_TACKLED:
			OnTackled((PLAYER_OBJ *)data1);
			return 1;

		case MSG_TAKEN_DOWN:
			OnTakenDown();
			return 1;

		case MSG_BALL_FUMBLED:
			OnBallFumbled();
			return 1;

		case MSG_HANDOFF_GIVEN:
			OnHandOffGiven();
			return 1;

		case MSG_FAKE_HANDOFF_GIVEN:
			OnFakeHandOffGiven();
			return 1;
		}
	
	return -1;
	}





void PLAYER_OBJ::OnBallHiked()
	{

	//////////////////////////////////////
	//									//
	// Used to handle ball hiked events //
	//									//
	//////////////////////////////////////


	BeginPostHikeActions();
	}





void PLAYER_OBJ::OnHandOffGiven()
	{

	/////////////////////////////////////////
	//									   //
	// Used to handle handoff given events //
	//									   //
	/////////////////////////////////////////

	

	// Acquire the ball

	GetBall();

	// or fumble
	}





void PLAYER_OBJ::OnFakeHandOffGiven()
	{

	//////////////////////////////////////////////
	//									        //
	// Used to handle fake handoff given events //
	//										    //
	//////////////////////////////////////////////


	// Pop the current action

	Actions.Pop();
	}





void PLAYER_OBJ::OnBallThrown(int time)
	{

	///////////////////////////////////////
	//									 //
	// Used to handle ball thrown events //
	//									 //
	///////////////////////////////////////



	// If this player cant reach the ball before it lands, then exit

	if (TimeToPosition(Ball.CatchSpot.Wld.X, Ball.CatchSpot.Wld.Y) <= Ball.TimeToCatchSpot || SideNum == OFFENSE)
		{
		Dest.X = Ball.CatchSpot.Wld.X;
		Dest.Y = Ball.CatchSpot.Wld.Y;
		}
	else if (TimeToPosition(Ball.LandingSpot.Wld.X, Ball.LandingSpot.Wld.Y) <= Ball.TimeToLandingSpot + 20)
		{
		Dest.X = Ball.LandingSpot.Wld.X;
		Dest.Y = Ball.LandingSpot.Wld.Y;
		}
	else if (TimeToPosition(Ball.InRangeSpot.Wld.X, Ball.InRangeSpot.Wld.Y) <= Ball.TimeToInRangeSpot)
		{
		Dest.X = Ball.InRangeSpot.Wld.X;
		Dest.Y = Ball.InRangeSpot.Wld.Y;
		}
	else
		return;



	// Clear out the actions 

	Actions.Clear();


	// Push the delay action

	Actions.PushEnd(ACTION_DELAY, rand() % FPS);


	// Push the catch ball action

	Actions.PushEnd(ACTION_CATCH_BALL, -1);
	}





void PLAYER_OBJ::OnBallReceived(PLAYER_OBJ * target)
	{

	/////////////////////////////////////////
	//									   //
	// Used to handle ball received events //
	//									   //
	/////////////////////////////////////////


	int LastActionType;


	// Store the last action type

	LastActionType = Actions.GetType();


	// Clear out the actions 

	Actions.Clear();


	// If this player was blocking, being blocked, grappling or being grappled, repush that
	// action



	// Otherwise, push the last action with a delayed time (based on AWARENESS)

	//else if (target != this)
	//	Actions.PushEnd(LastActionType, 0);


	// Do nothing if this is the receiver //

	if (target == this)	
		return;

	

	// If the player who received the ball is on this player's team
	// then block for that player and set UserControl to false

	if (target->SideNum == SideNum)
		Actions.PushEnd(ACTION_BLOCK_FOR_BALL_HOLDER);

	// else if the player who received the ball is on the other team
	// then track that player

	else
		{
		TrackTarget = target;
		Actions.PushEnd(ACTION_TACKLE_BALL_HOLDER);
		}
	}





void PLAYER_OBJ::OnBallFumbled()
	{

	////////////////////////////////////////
	//									  //
	// Used to handle ball fumbled events //
	//									  //
	////////////////////////////////////////


	int LastActionType;


	// Store the last action type

	LastActionType = Actions.GetType();


	// Clear out the actions 

	Actions.Clear();


	// If this player was blocking, being blocked, grappling or being grappled, repush that
	// action

	//if (LastActionType == ACTION_GRAPPLE || LastActionType == ACTION_BREAKGRAPPLE || 
	//	LastActionType == ACTION_BLOCK || LastActionType == ACTION_BREAKBLOCK)
	//	Actions.PushEnd(LastActionType, -1);


	// Otherwise, push the last action with a delayed time (based on AWARENESS)

	//else if (target != this)
	//	Actions.PushEnd(LastActionType, 0);


	// Push the pickup ball action 

	Actions.PushEnd(ACTION_DELAY, FPS);
	Actions.PushEnd(ACTION_RECOVER_FUMBLE);
	}





void PLAYER_OBJ::OnBallPassedScrimmage(PLAYER_OBJ * target)
	{

	/////////////////////////////////////////////////
	//											   //
	// Used to handle ball passed scrimmage events //
	//											   //
	/////////////////////////////////////////////////


	// Do nothing if this is the player

	if (target == this)
		return;


	Actions.Clear();
	

	// If the player is on this side, then block for him

	if (target->SideNum == SideNum)
		{
		Actions.Delay(rand() % (FPS * 2));
		Actions.PushEnd(ACTION_BLOCK_FOR_BALL_HOLDER);
		}


	// else if the player who has the ball is on the other team
	// then track that player

	else
		{
		TrackTarget = target;
		Actions.Delay(rand() % (FPS * 5));
		Actions.PushEnd(ACTION_TACKLE_BALL_HOLDER);
		}		
	}





void PLAYER_OBJ::OnPlayDead()
	{

	/////////////////////////////////////
	//								   //
	// Used to handle play dead events //
	//								   //
	/////////////////////////////////////


	// Just stop running

	Actions.Clear();
	Stand();
	}





void PLAYER_OBJ::OnTouchdown(PLAYER_OBJ * target)
	{

	/////////////////////////////////////
	//								   //
	// Used to handle touchdown events //
	//								   //
	/////////////////////////////////////


	// Celebrate if this player's team 
	
	Actions.Clear();

	if (target->SideNum == SideNum)
		Celebrate();
	else
		Complain();
	}





DWORD PLAYER_OBJ::OnGrappled(PLAYER_OBJ * target)
	{

	////////////////////////////////////
	//								  //
	// Used to handle grappled events //
	//								  //
	////////////////////////////////////


	float dirx, diry;


	if (State != STATE_STAND && State != STATE_RUN && State != STATE_THROW && State != STATE_BREAKGRAPPLE)
		return (DWORD)FALSE;


	if (!AddGrappler(target))
		return FALSE;


	// Get the direction of the grappler 

	GetDirectionToSpot(target->Wld.X, target->Wld.Y, &dirx, &diry);

	
	// Set the state to break grapple

	BreakGrapple(dirx, diry);


	return (DWORD)TRUE;
	}





void PLAYER_OBJ::OnGrappleBroken(PLAYER_OBJ * target)
	{

	//////////////////////////////////////////
	//								        //
	// Used to handle grapple broken events //
	//								        //
	//////////////////////////////////////////


	RemoveGrappler(target);

	if (NumGrapplers == 0)
		Stand();
	}





void PLAYER_OBJ::OnTackled(PLAYER_OBJ * target)
	{

	///////////////////////////////////
	//								 //
	// Used to handle tackled events //
	//								 //
	///////////////////////////////////


	LayDown();
	}





void PLAYER_OBJ::OnTakenDown()
	{

	//////////////////////////////////////
	//									//
	// Used to handle taken down events //
	//									//
	//////////////////////////////////////


	RemoveAllGrapplers();


	if (HasBall)
		SendMessage(0, MSG_BALL_HOLDER_DOWN, 0, (DWORD)this);


	LayDown();
	}





void PLAYER_OBJ::Stop()
	{

	///////////////////////////
	//						 //
	// Used to stop movement //
	//						 //
	///////////////////////////


	Vel.X		= 0.0f;
	Vel.Y		= 0.0f;
	DestVel.X	= 0.0f;
	DestVel.Y	= 0.0f;
	Acc.X		= 0.0f;
	Acc.Y		= 0.0f;
	}




void PLAYER_OBJ::SlowStop()
	{

	////////////////////////////////////
	//								  //
	// Used to slowly stop the player //
	//								  //
	////////////////////////////////////

	//Acc.X		= 0.05f;
	//Acc.Y		= 0.05f;
	//DestVel.X	= 0.0f;
	//DestVel.Y	= 0.0f;

	//if (Vel.X > 0.0f || Acc.X > 0.0f)	Acc.X = -0.15f;
	//if (Vel.Y > 0.0f || Acc.Y > 0.0f)	Acc.Y = -0.15f;

	SetState(STATE_SLOWDOWN);
	}





void PLAYER_OBJ::UpdateDeltas()
	{

	///////////////////////////////////////////////
	//											 //
	// Used to calculate the new delta values by //
	// the move direction						 //
	//											 //
	///////////////////////////////////////////////


	Delta.X = MoveDir.X * Vel.X;
	Delta.Y = MoveDir.Y * Vel.Y;
	Delta.Z -= GRAVITY;
	}




int PLAYER_OBJ::GetDirection(float xdir, float ydir)
	{

	/////////////////////////////////////////////////////////////////
	//															   //
	// Used to get a direction constant based on the xdir and ydir //
	//															   //				
	/////////////////////////////////////////////////////////////////


	int dir		= 0;
	BOOL left	= FALSE;
	BOOL right	= FALSE;
	BOOL up		= FALSE;
	BOOL down	= FALSE;


	// Set the left / right flags

	if (xdir <= -0.5f)
		left = TRUE;
	else if (xdir >= 0.5f)
		right = TRUE;


	// Set the up / down flags

	if (ydir <= -0.5f)
		up = TRUE;
	else if (ydir >= 0.5f)
		down = TRUE;


	// Set the dir variable based on the set flags

	if		(up && left)		dir = DIR_UPLEFT;
	else if (up && right)		dir = DIR_UPRIGHT;
	else if (up)				dir = DIR_UP;
	else if (down && left)		dir = DIR_DOWNLEFT;
	else if (down && right)		dir = DIR_DOWNRIGHT;
	else if (down)				dir = DIR_DOWN;
	else if (left)				dir = DIR_LEFT;
	else if (right)				dir = DIR_RIGHT;


	return dir;
	}





void PLAYER_OBJ::Face(float xdir, float ydir)
	{

	/////////////////////////////////////////////
	//										   //
	// Used to face the player towards a point //
	//										   //
	/////////////////////////////////////////////


	FaceDir = GetDirection(xdir, ydir);
	}




BOOL PLAYER_OBJ::IsStanding()
	{

	/////////////////////////////////////////////
	//										   //
	// Used to check if the player is standing //
	//										   //
	/////////////////////////////////////////////


	return State == STATE_STAND;
	}




BOOL PLAYER_OBJ::IsFacing(float xdir, float ydir)
	{

	///////////////////////////////////////////////////////////////////
	//																 //
	// Used to check if the player is facing the specified direction //
	//																 //
	///////////////////////////////////////////////////////////////////


	int dir;


	dir = GetDirection(xdir, ydir);

	return (FaceDir == dir);
	}




void PLAYER_OBJ::FaceMoveDirection()
	{

	////////////////////////////////////////////////////////
	//													  //
	// Used to face the player towards the move direction //
	//													  //
	////////////////////////////////////////////////////////


	int dir;


	dir = GetDirection(MoveDir.X, MoveDir.Y);

	if (dir != DIR_NONE)	FaceDir = dir;
	}





////////////////////
// ROLL FUNCTIONS //
////////////////////





BOOL PLAYER_OBJ::RollForCatch()
	{

	////////////////////////////////////////
	//									  //
	// Used to perform a roll for a catch //
	//									  //
	////////////////////////////////////////


	int modifier	= 0;
	int difficulty	= 10;

	
	// Accumulate the modifiers

	modifier += PlayerInfo->Attrib.Catch.Bonus();


	// Adjust the difficulty

	difficulty += Ball.Delta.Z > 0 ? int(Ball.Delta.Z) : 0;
	difficulty += !IsStanding() ? 1 : -4;
	difficulty += SideNum == DEFENSE ? 4 : -4;
	difficulty += GetNumberOfDefendersNear();


	return Roll(20, modifier, difficulty);
	}





BOOL PLAYER_OBJ::RollForCatchSnap()
	{

	/////////////////////////////////////////////
	//									       //
	// Used to perform a roll for a catch snap //
	//									       //
	/////////////////////////////////////////////


	int modifier	= 0;
	int difficulty	= 1;

	
	// Accumulate the modifiers

	//modifier += PlayerInfo->Attrib.Catch.Bonus();


	// Adjust the difficulty

	//difficulty += Ball.Delta.Z > 0 ? int(Ball.Delta.Z) : 0;
	//difficulty += !IsStanding() ? 1 : -4;
	//difficulty += SideNum == DEFENSE ? 4 : -4;
	//difficulty += GetNumberOfDefendersNear();


	return Roll(100, modifier, difficulty);
	}




BOOL PLAYER_OBJ::RollForGrappleBreak(PLAYER_OBJ * target)
	{

	////////////////////////////////////////////////
	//											  //
	// Used to perform a roll for a grapple break //
	//											  //
	////////////////////////////////////////////////


	BOOL retval;
	int modifier	= 0;
	int difficulty	= 15;

	
	// Accumulate the modifiers

	modifier += PlayerInfo->Attrib.Strength.Bonus();
	modifier += PlayerInfo->Attrib.Stamina.Bonus();


	// Adjust the difficulty

	difficulty += target->PlayerInfo->Attrib.Strength.Bonus();
	difficulty += target->PlayerInfo->Attrib.Stamina.Bonus();


	// Perform the roll 

	retval = Roll(20, modifier, difficulty);


	// On success, send the messages

	if (retval)
		{
		SendMessage(target->GetMsgTargetID(), MSG_TAKEN_DOWN, 0, (DWORD)this);
		SendMessage(GetMsgTargetID(), MSG_GRAPPLE_BROKEN, 0, (DWORD)target);
		}


	return retval;
	}





BOOL PLAYER_OBJ::RollForTakeDown()
	{

	///////////////////////////////////////////
	//										 //
	// Used to perform a roll for a takedown //
	//										 //
	///////////////////////////////////////////


	BOOL retval;
	int modifier	= 0;
	int difficulty	= 15;

	

	// Accumulate the modifiers

	modifier += PlayerInfo->Attrib.Strength.Bonus();
	modifier += PlayerInfo->Attrib.Stamina.Bonus();


	// Adjust the difficulty

	difficulty += GrappleTarget->PlayerInfo->Attrib.Strength.Bonus();
	difficulty += GrappleTarget->PlayerInfo->Attrib.Stamina.Bonus();



	// Perform the roll

	retval = Roll(20, modifier, difficulty);


	// On success, send the messages

	if (retval)
		{
		SendMessage(GrappleTarget->GetMsgTargetID(), MSG_TAKEN_DOWN, 0, (DWORD)this);
		Stand();
		}


	return retval;
	}





int PLAYER_OBJ::TimeToPosition(float xpos, float ypos)
	{

	//////////////////////////////////////////////////////////////
	//															//
	// Used to calculate the time in frames that it would take  //
	// this player to reach the position specified by xpos/ypos //
	//															//
	//////////////////////////////////////////////////////////////


	float distx, disty;
	float distance;

	
	// Calculate the distance to the spot

	distx = Wld.X - xpos;
	disty = Wld.Y - ypos;
	distance = sqrt((distx * distx) + (disty * disty));


	// Calculate the amount of frame it would take to reach the spot

	return (Round(distance / DestVel.X));
	}





void PLAYER_OBJ::GetDirectionToSpot(float xpos, float ypos, float * pxdir, float * pydir)
	{

	///////////////////////////////////////////////////
	//												 //
	// Used to get the direction to a specified spot //
	//												 //
	///////////////////////////////////////////////////


	float distx, disty, totaldist;


	// Validate the pointers 

	if (pxdir == NULL || pydir == NULL)
		return;


	// Get the distance to the spot

	distx = xpos - Wld.X;
	disty = ypos - Wld.Y;



	// Assign the pointer values

	
	totaldist = fabs(distx) + fabs(disty);


	if (totaldist == 0.0f)
		{
		*pxdir = 0.0f;
		*pydir = 0.0f;
		}
	else
		{
		*pxdir = distx / totaldist;
		*pydir = disty / totaldist;
		}
	}




float PLAYER_OBJ::GetDistanceToSpot(float xpos, float ypos)
	{

	//////////////////////////////////////
	//									//
	// Used to get a distance to a spot //
	//									//
	//////////////////////////////////////


	float distx, disty;


	// Get the x/y distances to the spot

	distx = xpos - Wld.X;
	disty = ypos - Wld.Y;


	// Return the distance

	return (sqrtf((distx * distx) + (disty * disty)));
	}





int PLAYER_OBJ::GetNumberOfDefendersNear()
	{

	/////////////////////////////////////////////////////////////
	//														   //
	// Used to return the number of defenders near this player //
	//														   //
	/////////////////////////////////////////////////////////////

	
	PLAYER_OBJ * target;
	int i;
	int numdefenders = 0;


	for (i = 0; i < MAX_SIDE_PLAYERS; i++)
		{
		target = &Side[!SideNum].Player[i];

		if (target->TrackTarget == this && GetDistanceToSpot(target->Wld.X, target->Wld.Y) <= Width * 2)
			numdefenders++;
		}

	return numdefenders;
	}





BOOL PLAYER_OBJ::IsPlayerInRange(PLAYER_OBJ * target, float distx, float disty)
	{

	//////////////////////////////////////////////////////////////////////////
	//																		//
	// Used to check if a player is within a specified range of this player //
	//																		//
	//////////////////////////////////////////////////////////////////////////
	
	
	BOOL inrangex, inrangey;


	if (GameInfo.Direction[TeamNum] == DIR_LEFT)
		{
		inrangex = (target->Wld.X >= (Wld.X + distx));
		inrangey = (target->Wld.Y <= Wld.Y + disty && target->Wld.Y >= Wld.Y - disty);
		}
	else
		{
		inrangex = (target->Wld.X <= (Wld.X - distx));
		inrangey = (target->Wld.Y <= Wld.Y + disty && target->Wld.Y >= Wld.Y - disty);
		}


	return (inrangex && inrangey);
	}





PLAYER_OBJ * PLAYER_OBJ::FindNearestPlayerToBlock()
	{

	////////////////////////////////////////////////
	//											  //
	// Used to find the nearest opponent to block //
	//											  //
	////////////////////////////////////////////////


	PLAYER_OBJ * nearest = NULL;
	float playerdist;
	float lastdist = 9999999.0f;
	int i;


	// Check each opponent 

	for (i = 0; i < MAX_SIDE_PLAYERS; i++)
		{

		// If the opponent is already grappling then continue

		if (Side[!SideNum].Player[i].State == STATE_BREAKGRAPPLE)
			continue;

		
		// Get the distance to the opponent

		playerdist = GetDistanceToSpot(Side[!SideNum].Player[i].Wld.X, Side[!SideNum].Player[i].Wld.Y);

		
		// If this opponent is closer than the last, set the flag to this opponent

		if (playerdist < lastdist)
			{
			nearest = &Side[!SideNum].Player[i];
			lastdist = playerdist;
			}
		}


	// Return the pointer to the nearest opponent
	return nearest;
	}





PLAYER_OBJ * PLAYER_OBJ::FindUntargetedReceiver()
	{

	///////////////////////////////////////////////////////////////////////
	//																	 //
	// Used to find a receiver who is not yet targeted by another player //
	//																	 //
	///////////////////////////////////////////////////////////////////////


	PLAYER_OBJ * target = NULL;
	BOOL targeted;
	int i, ii;


	// Scroll through each player of the opposite team ...

	for (i = 0; i < MAX_SIDE_PLAYERS; i++)
		{

		// And if a receiver is found ...

		if (Side[!SideNum].Player[i].Flag.Receiver)
			{	
			target		= &Side[!SideNum].Player[i];
			targeted	= FALSE;


			// Check the TrackTarget of each player on this team to make sure the player
			// is not already targeted

			for (ii = 0; ii < MAX_SIDE_PLAYERS; ii++)
				if (this != &Side[SideNum].Player[ii] && Side[SideNum].Player[ii].TrackTarget == target)
					targeted = TRUE;


			// If not targeted by anyone else, return the pointer

			if (!targeted)
				return target;
			}
		}


	return NULL;
	}





PLAYER_OBJ * PLAYER_OBJ::FindClosestUntargetedReceiver()
	{

	/////////////////////////////////////////////////////////////////////////////////
	//																			   //
	// Used to find the closest receiver who is not yet targeted by another player //
	//																			   //
	/////////////////////////////////////////////////////////////////////////////////


	PLAYER_OBJ * target = NULL;
	PLAYER_OBJ * finaltarget = NULL;
	BOOL targeted;
	int i, ii;
	float dist, lastdist = 99999.0f;


	// Scroll through each player of the opposite team ...

	for (i = 0; i < MAX_SIDE_PLAYERS; i++)
		{

		// And if a receiver is found ...

		if (Side[!SideNum].Player[i].Flag.Receiver)
			{	
			target		= &Side[!SideNum].Player[i];
			targeted	= FALSE;


			// Check the TrackTarget of each player on this team to make sure the player
			// is not already targeted

			for (ii = 0; ii < MAX_SIDE_PLAYERS; ii++)
				if (this != &Side[SideNum].Player[ii] && Side[SideNum].Player[ii].TrackTarget == target)
					targeted = TRUE;


			// If not targeted by anyone else, return the pointer

			if (!targeted)
				{
				dist = GetDistanceToSpot(target->Wld.X, target->Wld.Y);

				if (dist < lastdist)
					{
					finaltarget = &Side[!SideNum].Player[i];
					lastdist = dist;
					}
				}
			}
		}


	return finaltarget;
	}






BOOL PLAYER_OBJ::AddGrappler(PLAYER_OBJ * target)
	{

	//////////////////////////////////////////////////
	//												//
	// Used to add a grappler to the grappler array //
	//												//
	//////////////////////////////////////////////////


	// Check if amount of grappler slots is full

	if (NumGrapplers >= MAX_GRAPPLERS)
		return FALSE;


	// Check if grappler is already set

	for (int i = 0; i < NumGrapplers; i++)
		if (Grapplers[i] == target)
			return FALSE;


	Grapplers[NumGrapplers] = target;
	NumGrapplers++;

	return TRUE;
	}




void PLAYER_OBJ::RemoveGrappler(PLAYER_OBJ * target)
	{

	///////////////////////////////////////////////////////
	//													 //
	// Used to remove a grappler from the grappler array //
	//													 //
	///////////////////////////////////////////////////////


	for (int i = 0; i < NumGrapplers - 1; i++)
		if (Grapplers[i] == target)
			{
			memcpy(&Grapplers[i], &Grapplers[i + 1], sizeof(PLAYER_OBJ *) * (NumGrapplers - 1 - i));
			NumGrapplers--;
			return;
			}

	NumGrapplers--;
	}





void PLAYER_OBJ::Damage(float amt)
	{

	////////////////////////////////////////
	//									  //
	// Used to damage the players stamina //
	//									  //
	////////////////////////////////////////


	PlayerInfo->Attrib.Stamina.Val -= amt;

	if (PlayerInfo->Attrib.Stamina.Val < 0.0f)
		PlayerInfo->Attrib.Stamina.Val = 0.0f;

	if (PlayerInfo->Attrib.Stamina.Val > 100.0f)
		PlayerInfo->Attrib.Stamina.Val = 100.0f;
	}




