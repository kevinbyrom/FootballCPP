#include <windows.h>
#include "CheckTimeStage.h"
#include "Football.h"



void CHECK_TIME_STAGE::Opening()
	{

	//////////////////////////
	//						//
	// Opening of the stage //
	//						//
	//////////////////////////
	}



void CHECK_TIME_STAGE::Closing(STAGE * Stage)
	{

	//////////////////////////
	//						//
	// Closing of the stage //
	//						//
	//////////////////////////
	}



void CHECK_TIME_STAGE::Loop()
	{
	
	/////////////////////////////
	//						   //
	// Main loop for the stage //
	//						   //
	/////////////////////////////
			
	MainGame.OpenSelectPlayStage();
	}







