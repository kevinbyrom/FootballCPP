#include <windows.h>
#include "Quaterback.h"


void QUATERBACK::OnBallHiked()
	{
	ControlType = CONTROL_USER;
	//State = STATE_USERCONTROL;
	}